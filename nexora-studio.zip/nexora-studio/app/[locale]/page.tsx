import { setRequestLocale, getTranslations } from "next-intl/server";
import { Hero } from "@/components/sections/Hero";
import { ValueProposition } from "@/components/sections/ValueProposition";
import { WhyWebsite } from "@/components/sections/WhyWebsite";
import { Services } from "@/components/sections/Services";
import { Showcase } from "@/components/sections/Showcase";
import { Process } from "@/components/sections/Process";
import { About } from "@/components/sections/About";
import { FinalCta } from "@/components/sections/FinalCta";
import { Footer } from "@/components/sections/Footer";
import { Navbar } from "@/components/ui/Navbar";
import { FloatingWhatsApp } from "@/components/ui/FloatingWhatsApp";
import { SmoothScroll } from "@/components/ui/SmoothScroll";
import { ScrollAnimations } from "@/components/ui/ScrollAnimations";
import { localeUrl, SITE_URL, site } from "@/lib/site";

export default async function Home({ params }: PageProps<"/[locale]">) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations({ locale, namespace: "meta" });

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    "@id": `${SITE_URL}/#organization`,
    name: site.name,
    slogan: t("title").split("|")[1]?.trim(),
    description: t("description"),
    url: localeUrl(locale),
    logo: `${SITE_URL}/icons/icon-dark-512.png`,
    image: `${SITE_URL}/og/${locale}`,
    email: site.email,
    telephone: `+${site.whatsappNumber}`,
    founder: { "@type": "Person", name: site.founder, jobTitle: "Founder & CEO" },
    areaServed: ["BR", "EU", "US"],
    knowsLanguage: ["pt-BR", "en"],
    serviceType: ["Web design", "Web development", "SEO", "Digital marketing"],
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "sales",
      telephone: `+${site.whatsappNumber}`,
      email: site.email,
      availableLanguage: ["Portuguese", "English"],
    },
  };

  return (
    <>
      <SmoothScroll />
      <Navbar />
      <main id="conteudo" tabIndex={-1} className="outline-none">
        <Hero />
        <ValueProposition />
        <WhyWebsite />
        <Services />
        <Showcase />
        <Process />
        <About />
        <FinalCta />
      </main>
      <Footer />
      <FloatingWhatsApp />
      <ScrollAnimations />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
    </>
  );
}
