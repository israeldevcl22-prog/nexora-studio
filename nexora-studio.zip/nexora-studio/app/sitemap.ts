import type { MetadataRoute } from "next";
import { localeUrl } from "@/lib/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const languages = { "pt-BR": localeUrl("pt"), en: localeUrl("en") };
  return (["pt", "en"] as const).map((locale) => ({
    url: localeUrl(locale),
    lastModified: new Date(),
    changeFrequency: "monthly",
    priority: locale === "pt" ? 1 : 0.9,
    alternates: { languages },
  }));
}
