import fs from "node:fs";
import path from "node:path";
import { ImageResponse } from "next/og";
import { routing } from "@/i18n/routing";

export const dynamic = "force-static";

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

const TAGLINE = {
  pt: "SITES QUE IMPULSIONAM NEGÓCIOS",
  en: "WEBSITES THAT DRIVE BUSINESS",
} as const;

/** 1200×630 share image: the official light wordmark on black + slogan. */
export async function GET(_req: Request, ctx: RouteContext<"/og/[locale]">) {
  const { locale } = await ctx.params;
  const tagline = TAGLINE[locale === "en" ? "en" : "pt"];
  const png = fs.readFileSync(path.join(process.cwd(), "public/brand/logo-wordmark-light.png"));
  const src = `data:image/png;base64,${png.toString("base64")}`;
  const w = 660;
  const h = Math.round((w * 182) / 812);

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: "radial-gradient(80% 90% at 50% 0%, #3A3A3A 0%, #0E0E0E 70%)",
        }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={src} width={w} height={h} alt="" />
        <div style={{ width: 48, height: 1, background: "#3A3A3A", marginTop: 56 }} />
        <div style={{ marginTop: 40, fontSize: 20, letterSpacing: 9, color: "#A7A3A0" }}>
          {tagline}
        </div>
      </div>
    ),
    { width: 1200, height: 630 }
  );
}
