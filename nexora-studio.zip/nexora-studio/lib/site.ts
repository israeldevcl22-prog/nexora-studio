/**
 * Public address of the site.
 * 1. NEXT_PUBLIC_SITE_URL (set it when there is a custom domain)
 * 2. the production address Vercel provides automatically (xxx.vercel.app)
 * 3. localhost during development
 * Read it on the server only (pages, metadata, sitemap…): the Vercel variable
 * is not exposed to client components.
 */
export const SITE_URL = (
  process.env.NEXT_PUBLIC_SITE_URL ||
  (process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : "http://localhost:3000")
).replace(/\/+$/, "");

/** SITE_URL without the protocol, e.g. "nexora-studio.vercel.app". */
export const SITE_DOMAIN = SITE_URL.replace(/^https?:\/\//, "");

export const site = {
  name: "Nexora Studio",
  email: "contactisrael.dev22@gmail.com",
  whatsappNumber: "5524981754835",
  whatsappDisplay: "+55 24 98175-4835",
  founder: "Israel",
} as const;

export function localeUrl(locale: string, path = "") {
  const prefix = locale === "pt" ? "" : `/${locale}`;
  return `${SITE_URL}${prefix}${path}`;
}
