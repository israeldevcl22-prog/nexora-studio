"use client";

import { useSyncExternalStore } from "react";

/** Shared state between the Hero timeline, the Navbar and the floating button. */
export type HeroState = {
  /** Navbar is hidden while the dark band crosses the screen. */
  navHidden: boolean;
  /** Reveal finished: full navbar and CTAs can show. */
  complete: boolean;
  /** Scrolled past the pinned hero. */
  past: boolean;
};

const initial: HeroState = { navHidden: false, complete: false, past: false };
let state: HeroState = initial;
const listeners = new Set<() => void>();

export function setHeroState(patch: Partial<HeroState>) {
  const next = { ...state, ...patch };
  if (
    next.navHidden === state.navHidden &&
    next.complete === state.complete &&
    next.past === state.past
  )
    return;
  state = next;
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function useHeroState() {
  return useSyncExternalStore(
    subscribe,
    () => state,
    () => initial
  );
}
