"use client";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import Lenis from "lenis";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger, useGSAP);
}

let lenis: Lenis | null = null;

/** Creates the single Lenis instance and wires it into GSAP's ticker. */
export function initLenis() {
  if (lenis || typeof window === "undefined") return lenis;
  lenis = new Lenis({ duration: 1.15, smoothWheel: true });
  lenis.on("scroll", ScrollTrigger.update);
  gsap.ticker.add(tick);
  gsap.ticker.lagSmoothing(0);
  return lenis;
}

function tick(time: number) {
  lenis?.raf(time * 1000);
}

export function destroyLenis() {
  gsap.ticker.remove(tick);
  lenis?.destroy();
  lenis = null;
}

export function getLenis() {
  return lenis;
}

export const NAV_OFFSET = 72;

/** Smooth scroll to an element id (falls back to native when Lenis is off). */
export function scrollToId(id: string, immediate = false) {
  const el = document.getElementById(id);
  if (!el) return;
  if (lenis) {
    lenis.scrollTo(el, { offset: id === "top" ? 0 : -NAV_OFFSET, immediate });
  } else {
    const y = el.getBoundingClientRect().top + window.scrollY - (id === "top" ? 0 : NAV_OFFSET);
    window.scrollTo({ top: y, behavior: "auto" });
  }
}

export function prefersReducedMotion() {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

export { gsap, ScrollTrigger, useGSAP };
