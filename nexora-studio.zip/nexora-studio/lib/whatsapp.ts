import { site } from "./site";

const baseMessages = {
  pt: "Olá Israel! Vi o site da Nexora Studio e gostaria de pedir um orçamento para o meu site.",
  en: "Hi Israel! I saw the Nexora Studio website and I'd like to get a quote for my website.",
} as const;

const contextJoin = {
  pt: (ctx: string) => ` Quero um site parecido com o da ${ctx}.`,
  en: (ctx: string) => ` I'd like a website similar to ${ctx}'s.`,
} as const;

/**
 * Single source of truth for every WhatsApp link on the site.
 * `context` optionally names a reference project (e.g. "Liga Forte").
 */
export function whatsappLink(locale: string, context?: string) {
  const lang = locale === "en" ? "en" : "pt";
  let text: string = baseMessages[lang];
  if (context) text += contextJoin[lang](context);
  return `https://wa.me/${site.whatsappNumber}?text=${encodeURIComponent(text)}`;
}
