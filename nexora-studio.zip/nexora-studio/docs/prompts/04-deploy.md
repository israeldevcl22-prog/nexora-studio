# Prompt — Preparar o site Nexora Studio para GitHub e Vercel

> Coloque este arquivo na raiz do projeto e diga ao Claude Code: *"Leia o PROMPT-DEPLOY.md e prepare o projeto para o deploy, passo a passo."*

---

## Contexto

O site da Nexora Studio (Next.js + Tailwind + GSAP + Lenis + next-intl) está pronto e aprovado. Agora ele precisa ir para o **GitHub** e, de lá, para a **Vercel**.

**Não altere o design, os textos nem as animações.** Esta tarefa é só de preparação, limpeza e publicação. Se encontrar um erro que impeça o build, corrija com a menor mudança possível e me avise do que mudou.

Explique cada passo em português simples, porque sou iniciante em Git, GitHub e Vercel. Sempre que precisar que eu faça algo (login, clicar em algum lugar), pare e me diga exatamente o que fazer.

---

## 1. Verificação do projeto

1. Rode `npm install` e confirme que não há erros.
2. Rode `npm run lint` e corrija os avisos que forem erros reais (não mude estilo de código à toa).
3. Rode `npm run build`. **O build tem de passar sem erros**, que é exatamente o que a Vercel vai rodar.
4. Rode `npm run start` e confira rapidamente se `/` (PT) e `/en` (EN) abrem.
5. Confirme que o `package.json` tem os scripts `dev`, `build`, `start` e `lint`, e adicione `"engines": { "node": ">=20" }`.

## 2. Limpeza

1. Crie a pasta `docs/prompts/` e mova para ela todos os arquivos de prompt da raiz (`PROMPT.md`, `PROMPT-DEPLOY.md` etc.). Eles ficam guardados como histórico, mas fora da raiz.
2. Apague arquivos que não são usados pelo site: screenshots de teste, arquivos temporários, scripts de Playwright usados só uma vez (se forem úteis, mova para `scripts/`).
3. Em `public/brand/`, mantenha só os logos usados pelo site. As referências grandes (`brand-board.png`, `logo-system-transparent.png`) vão para `docs/brand/`, para não pesarem no site publicado.
4. Garanta que nenhuma imagem em `public/` passa de ~500 KB. Converta para `.webp` se precisar.

## 3. Endereço do site (domínio)

Ainda não tenho domínio próprio; o site vai rodar primeiro no endereço gratuito da Vercel (`algo.vercel.app`).

1. Em `lib/site.ts`, troque o domínio fixo `nexorastudio.com.br` por:
   ```ts
   export const SITE_URL =
     process.env.NEXT_PUBLIC_SITE_URL ??
     (process.env.VERCEL_PROJECT_PRODUCTION_URL
       ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
       : 'http://localhost:3000');
   ```
2. Faça `sitemap`, `robots`, metadata (`metadataBase`), Open Graph, `hreflang` e JSON-LD usarem `SITE_URL`.
3. Na barra de endereço da janela "Nexora" (seção de proposta de valor), mostre o domínio a partir de `SITE_URL`, sem `https://`.
4. Crie `.env.example` com:
   ```
   # Endereço público do site (preencha quando tiver domínio próprio)
   NEXT_PUBLIC_SITE_URL=
   ```
   Nunca crie nem envie um `.env` com valores reais.

## 4. Arquivos para o GitHub

1. **`.gitignore`** completo para Next.js: `node_modules/`, `.next/`, `out/`, `.vercel/`, `.env*` (exceto `.env.example`), `*.log`, `.DS_Store`, `Thumbs.db`, `coverage/`, arquivos de editor.
2. **`README.md`** em português, curto e bonito:
   - Nome e descrição (Nexora Studio — Sites que impulsionam negócios)
   - Stack usada
   - Como rodar localmente (`npm install`, `npm run dev`)
   - Estrutura de pastas resumida
   - Como trocar os projetos da vitrine (`data/projects.ts`)
   - Como editar os textos (`messages/pt.json` e `messages/en.json`)
   - Como fazer o deploy (resumo da seção 6 abaixo)
   - Contato: WhatsApp e e-mail do site
3. Não precisa de licença open source (o código é da Nexora). Se quiser, adicione no README: `© 2026 Nexora Studio. Todos os direitos reservados.`

## 5. Git e GitHub

1. Verifique se o Git está instalado (`git --version`). Se não estiver, me diga como instalar no Windows e pare.
2. Se o projeto ainda não for um repositório, rode `git init` e use a branch `main`.
3. Configure nome e e-mail do Git só se ainda não estiverem configurados (pergunte-me o nome; e-mail: `contactisrael.dev22@gmail.com`).
4. Rode `git status` e confira que **não** aparecem `node_modules`, `.next` nem `.env`.
5. Faça o primeiro commit: `feat: site Nexora Studio pronto para deploy`.
6. Criar o repositório no GitHub:
   - **Se o GitHub CLI (`gh`) estiver instalado e logado** (`gh auth status`): crie um repositório **privado** chamado `nexora-studio` com `gh repo create nexora-studio --private --source=. --push`.
   - **Se não estiver:** pare e me explique, passo a passo, como criar o repositório vazio `nexora-studio` em github.com (privado, sem README, sem .gitignore) e me peça o link. Depois rode `git remote add origin <link>` e `git push -u origin main`.
7. Confirme que o push funcionou e me mostre o link do repositório.

## 6. Vercel

A Vercel detecta Next.js sozinha, então **não crie `vercel.json`**, a menos que seja realmente necessário.

Me dê este passo a passo (e faça o que puder pelo terminal, se a Vercel CLI estiver instalada e logada):
1. Entrar em vercel.com e fazer login **com a conta do GitHub**.
2. **Add New → Project** e importar o repositório `nexora-studio`.
3. Framework: Next.js (automático). Não mudar build command nem output.
4. Variáveis de ambiente: nenhuma é obrigatória agora (`NEXT_PUBLIC_SITE_URL` só quando houver domínio próprio).
5. Clicar em **Deploy** e esperar.
6. Depois disso, cada `git push` na branch `main` publica o site automaticamente.

E explique também, rapidamente, como conectar um domínio próprio no futuro (Settings → Domains) e lembrar de preencher `NEXT_PUBLIC_SITE_URL`.

## 7. Checklist final (depois do deploy)

Me peça o link da Vercel e confira (ou me oriente a conferir):
- [ ] Site abre em `/` e `/en`
- [ ] Animação da hero funciona no desktop e no celular
- [ ] Todos os botões de WhatsApp abrem a conversa certa
- [ ] Imagens dos projetos e logos carregam
- [ ] `/sitemap.xml` e `/robots.txt` mostram o endereço da Vercel
- [ ] Ao colar o link no WhatsApp, aparece a pré-visualização com a imagem Open Graph

No fim, me entregue um resumo com: link do GitHub, link do site e o que fazer para atualizar o site no futuro (editar → `git add .` → `git commit -m "..."` → `git push`).
