# Prompt — Site Portfólio Nexora Studio (para Claude Code)

> **Antes de rodar:** crie a pasta do projeto, copie a pasta `brand/` deste pacote para `public/brand/` e cole todo o conteúdo abaixo da linha no Claude Code.
>
> Referências visuais incluídas:
>
> ![Brand board Nexora Studio](brand/brand-board.png)
> ![Sistema de logos Nexora Studio](brand/logo-system.png)

---

## 0. Contexto

Você vai construir o site portfólio da **Nexora Studio**, um estúdio de desenvolvimento web e marketing digital. O site precisa parecer uma peça de identidade de marca premium: minimalista, monocromático, editorial e cinematográfico. É o principal canal de vendas do estúdio, então cada seção deve levar o visitante a pedir orçamento pelo WhatsApp.

**Referências visuais obrigatórias** (leia as duas imagens antes de escrever qualquer código):
- `public/brand/brand-board.png` — brand board completo: paleta, tipografia, hero de referência, cards de serviços, mockups.
- `public/brand/logo-system.png` — sistema de logos: wordmark NEXORA + STUDIO, símbolo "N", ícones de app claro/escuro e versão horizontal.

Recrie o símbolo "N" e o wordmark "NEXORA" / "STUDIO" como **SVGs vetoriais** em `components/brand/` (não use os PNGs no site final, eles são só referência). Detalhe essencial: a haste diagonal do "N" tem um **brilho metálico em gradiente** (preto → cinza prateado → preto). Reproduza com `linearGradient`. O "A" do wordmark não tem a barra horizontal (estilo Λ).

---

## 1. Stack

- **Next.js (App Router) + TypeScript**
- **Tailwind CSS**
- **GSAP + ScrollTrigger** para a hero e as animações de scroll
- **Lenis** para scroll suave (integrado ao ScrollTrigger via `lenis.on('scroll', ScrollTrigger.update)` e `gsap.ticker`)
- **next-intl** para internacionalização: PT-BR (padrão, rota `/`) e EN (rota `/en`)
- **next/font** com **Manrope** (Google Fonts)
- Deploy pensado para **Vercel**
- Sem bibliotecas de UI prontas. Componentes próprios.

---

## 2. Identidade visual

### Tokens de cor (CSS variables + tema Tailwind)
| Token | Hex | Uso |
|---|---|---|
| `--off-white` | `#F8F6F3` | Fundo claro principal |
| `--cinza-claro` | `#E5E2DE` | Bordas, superfícies, "N" discreto da hero |
| `--cinza-medio` | `#A7A3A0` | Textos secundários, legendas |
| `--cinza-escuro` | `#3A3A3A` | Faixa da hero, superfícies escuras |
| `--preto` | `#0E0E0E` | Fundos escuros profundos, textos principais |

Não adicione nenhuma outra cor. Sem azul, sem gradientes coloridos. O único "brilho" do site é o metálico da haste do N.

### Tipografia
- **Manrope** em todo o site. Personalidade: moderna, minimalista, versátil, profissional.
- Títulos grandes, peso 500–600, tracking levemente negativo.
- Rótulos e eyebrows em CAIXA ALTA com letter-spacing largo (`0.3em`), tamanho pequeno, cor `--cinza-medio`. Ex.: `NOSSOS SERVIÇOS —`.
- O wordmark NEXORA tem letter-spacing bem aberto; STUDIO ainda mais aberto e menor.

### Linguagem visual
- Muito espaço em branco, grid limpo, bordas finas (`1px` `--cinza-claro`), cantos arredondados suaves (12–20px) em cards.
- Alternância entre seções off-white e seções pretas, como no brand board.
- Botões pill: off-white com texto preto sobre fundo escuro; preto com texto off-white sobre fundo claro. Seta `→` à direita.
- Ícones de linha fina (lucide-react ou SVG próprio), traço 1.5px.

---

## 3. Conteúdo do negócio

- **Marca:** Nexora Studio
- **Slogan:** Sites que impulsionam negócios
- **Fundador:** Israel, 16 anos, CEO e fundador
- **Mora em:** Portugal
- **Estuda:** Engenharia de Software na Escola Profissional de Aveiro (Aveiro, Portugal)
- **Atende:** empresas no Brasil, na Europa e nos EUA
- **WhatsApp:** +55 24 98175-4835
- **E-mail:** contactisrael.dev22@gmail.com
- **Domínio (placeholder):** `nexorastudio.com.br`

### Link do WhatsApp (helper único em `lib/whatsapp.ts`)
```
https://wa.me/5524981754835?text=<mensagem codificada>
```
Mensagem PT-BR: `Olá Israel! Vi o site da Nexora Studio e gostaria de pedir um orçamento para o meu site.`
Mensagem EN: `Hi Israel! I saw the Nexora Studio website and I'd like to get a quote for my website.`
Aceite um parâmetro opcional para contexto (ex.: vindo da vitrine: `...quero um site parecido com o da Liga Forte`).

---

## 4. Estrutura (nesta ordem)

1. Navbar
2. Hero com scroll reveal
3. Por que um site importa hoje
4. Serviços
5. Vitrine de projetos
6. Processo
7. Sobre o Israel
8. CTA final (WhatsApp)
9. Rodapé

---

## 5. Navbar

- Fixa, transparente sobre a hero; ganha fundo com blur e borda inferior fina após sair da hero. A cor do texto se adapta ao fundo (escuro na fase off-white, claro na fase escura).
- Esquerda: wordmark NEXORA (SVG).
- Links: Serviços · Projetos · Sobre · Contato (âncoras com scroll suave via Lenis).
- Direita: seletor `PT | EN` discreto + botão pill pequeno "Fale conosco" (abre o WhatsApp).
- Mobile: menu hambúrguer de linhas finas, abre um painel full-screen preto com os links grandes.
- **Durante a animação da hero a navbar fica mínima** (só o wordmark), para não competir com a revelação; links e CTA entram com fade quando a animação termina.

---

## 6. HERO — a peça central (scroll animation)

Sensação: uma peça de identidade sendo revelada. Movimento **lento, elegante, preciso**. Nada de bounce ou elástico. Use `ease: "power2.inOut"` / `"expo.out"` e `scrub: 1` para acompanhar o scroll com suavidade.

A seção fica **pinned** durante ~**300vh** de scroll no desktop (~**180vh** no mobile). Monte uma timeline GSAP única ligada ao ScrollTrigger.

### Estado inicial (0%)
- Tela quase toda **off-white** (`#F8F6F3`).
- Um **"N" enorme** (cerca de 70vh de altura), centralizado, em `--cinza-claro`, muito discreto, quase marca d'água. A haste diagonal já tem um leve brilho metálico, bem sutil.
- Embaixo, minúsculo: `ROLE PARA DESCOBRIR` em caixa alta com tracking largo e uma linha fina animada (pulso lento).

### Fase 1 (0% → 35%) — a haste vira a faixa
- A **haste diagonal do "N" cresce** ao longo do seu próprio ângulo até virar uma **faixa diagonal escura** (`--cinza-escuro` → `--preto`) que atravessa a tela inteira, de canto a canto.
- O brilho metálico corre ao longo da faixa (anime o `offset` do gradiente) enquanto ela cresce.
- As hastes verticais do "N" fazem fade-out.

### Fase 2 (35% → 60%) — o fundo escurece
- A faixa **se expande lateralmente** (anime um `clip-path: polygon(...)` diagonal) até cobrir todo o ecrã. O fundo agora é preto.
- A transição deve parecer uma cortina diagonal passando, não um fade.

### Fase 3 (60% → 80%) — o nome é revelado
- O "N" reaparece em tamanho normal, agora em off-white com o brilho metálico, e **encaixa** como a primeira letra do wordmark.
- As letras **E X O R A** entram uma a uma (stagger), com o **letter-spacing abrindo** de apertado para o espaçamento final.
- **STUDIO** aparece logo abaixo, menor, com fade e tracking ainda maior.

### Fase 4 (80% → 100%) — a frase e o CTA
- Surge a frase **"Sites que impulsionam negócios"** em caixa alta, tracking largo, `--cinza-medio`, com reveal de máscara de baixo para cima.
- **Só neste momento** aparece o botão pill de WhatsApp: **"Pedir orçamento →"**, pequeno e elegante.
- Navbar completa entra com fade.
- Uma linha fina e o texto `ROLE` sinalizam que o site continua.

### Requisitos técnicos da hero
- Construa o "N" e o wordmark como SVG inline para poder animar partes individualmente (hastes, letras).
- Use `will-change` e `transform`/`clip-path`/`opacity` apenas; nada que force layout.
- `ScrollTrigger.matchMedia` / `gsap.matchMedia()` para as versões desktop e mobile.
- **`prefers-reduced-motion: reduce`:** sem pin e sem animação. A hero aparece já no estado final (fundo preto, wordmark, frase e botão).
- Faça `ScrollTrigger.refresh()` depois das fontes carregarem para evitar saltos.
- Garanta 60fps; teste com o painel de performance.

---

## 7. Por que um site importa hoje

Fundo off-white. Eyebrow: `POR QUE TER UM SITE —`. Título: **"Sua empresa existe na internet? Seus clientes estão procurando."**

Quatro blocos em grid (2×2 desktop, 1 coluna mobile), número grande em fino (`01`, `02`...) e texto curto:

1. **Credibilidade imediata** — Antes de comprar, as pessoas pesquisam. Um site profissional mostra que sua empresa é séria e confiável.
2. **Ser encontrado no Google** — Quem procura pelo seu serviço precisa te encontrar, não o concorrente.
3. **Vendendo 24 horas por dia** — Seu site apresenta, explica e gera contatos mesmo enquanto você dorme.
4. **Independência das redes sociais** — Algoritmos mudam e perfis caem. Seu site é seu, e ninguém tira isso de você.

**Regra:** NÃO invente estatísticas. Se usar algum número, ele precisa vir com fonte real e verificável citada ao lado. Na dúvida, mantenha os argumentos sem números.

---

## 8. Serviços

Fundo off-white. Eyebrow: `NOSSOS SERVIÇOS —`. Quatro cards como no brand board (borda fina, ícone de linha, título, uma linha de descrição):

1. **Sites Profissionais** (ícone monitor) — Sites rápidos, modernos e feitos para converter visitantes em clientes.
2. **SEO e Posicionamento** (ícone gráfico de barras) — Estrutura otimizada para sua empresa aparecer no Google.
3. **Marketing Digital** (ícone megafone) — Estratégias para atrair o público certo para o seu negócio.
4. **Soluções Personalizadas** (ícone camadas) — Landing pages, cardápios digitais, catálogos e o que seu projeto precisar.

Hover: o card eleva levemente, a borda escurece, o ícone ganha leve deslocamento.

---

## 9. Vitrine de projetos

Fundo **preto**. Eyebrow: `PROJETOS —`. Título: **"Sites que já estão gerando resultados."**

Grid de 6 cards (2 colunas desktop, 1 mobile). Cada card: mockup do site (notebook ou celular), setor em eyebrow, nome, descrição de uma linha e link "Ver site →" (abre em nova aba). Os mockups devem seguir o estilo do brand board (aparelho escuro, sombra suave).

### Projetos reais
1. **Liga Forte** — `INDÚSTRIA` — Postes de fibra de vidro e artefatos de concreto.
   Descrição: *Site institucional focado em gerar orçamentos pelo WhatsApp e ser encontrado no Google.*
   Link: https://liga-forte.vercel.app
2. **LA Sanduicheria** — `GASTRONOMIA` — Hamburgueria em Guarulhos (SP).
   Descrição: *Cardápio digital com identidade própria e pedidos direto pelo WhatsApp.*
   Link: https://la-sanduicheria-site.vercel.app

**Screenshots:** gere capturas reais desses dois sites (Playwright, viewport 1440×900 para desktop e 390×844 para mobile), salve em `public/projects/` como `.webp` otimizado e use-as dentro dos mockups.

### Placeholders (4 cards prontos para trocar depois)
Os dados devem vir de um único arquivo `data/projects.ts` (com textos PT e EN), com campo `status: 'live' | 'placeholder'`. Os placeholders mostram uma tela neutra com o "N" ao centro e o selo discreto `EM BREVE`, sem link:

3. **Clínica** — `SAÚDE`
4. **Escritório de advocacia** — `JURÍDICO`
5. **Loja online** — `E-COMMERCE`
6. **Academia** — `FITNESS`

Animações: leve parallax nos mockups durante o scroll; hover com zoom sutil (scale 1.03) na imagem.

Depois da grade, CTA de WhatsApp discreto: **"Quer um site assim para a sua empresa? → Fale comigo"**.

---

## 10. Processo

Fundo off-white. Eyebrow: `COMO FUNCIONA —`. Quatro passos em linha horizontal (desktop) com linha fina conectando, que se desenha conforme o scroll; vertical no mobile:

1. **Conversa** — Entendo seu negócio, seus objetivos e seu público.
2. **Estratégia e design** — Estrutura e visual pensados para o seu cliente.
3. **Desenvolvimento** — Site rápido, responsivo e otimizado para o Google.
4. **Lançamento** — Publicação, ajustes finais e suporte.

---

## 11. Sobre o Israel

Fundo preto, layout em duas colunas.

- Esquerda: espaço para foto **em preto e branco** (`public/brand/israel.jpg`). Enquanto não houver foto, use um placeholder elegante: quadro `--cinza-escuro` com o "N" metálico centralizado.
- Direita: eyebrow `SOBRE —`, título **"Oi, eu sou o Israel."** e texto:

> Sou o fundador e CEO da Nexora Studio. Comecei a empresa aos 16 anos, enquanto estudo Engenharia de Software na Escola Profissional de Aveiro, em Portugal.
>
> Acredito que toda empresa merece uma presença digital à altura do que ela entrega. Por isso, cada site que faço une estratégia, design e tecnologia com um só objetivo: trazer resultado real para o seu negócio.
>
> Hoje atendo empresas no Brasil, na Europa e nos EUA, tudo de forma remota, com comunicação direta comigo do primeiro contato até o lançamento.

- Abaixo, três destaques pequenos em linha: `Fundador & CEO` · `Eng. de Software — EPA, Aveiro` · `Brasil · Europa · EUA`.
- Tom: confiante, jovem, direto. A idade aparece como prova de ambição, nunca como desculpa.

---

## 12. CTA final

Seção inspirada no bloco escuro do brand board ("Estratégia, design e tecnologia..."), com imagem arquitetônica em P&B ao lado (pode usar uma imagem livre do Unsplash ou um gradiente abstrato; nunca algo com marcas de terceiros).

- Wordmark NEXORA STUDIO pequeno.
- Título: **"Vamos tirar o seu site do papel?"**
- Subtítulo: *Estratégia, design e tecnologia para o crescimento da sua marca no ambiente digital.*
- Botão pill (o maior do site, mas ainda elegante): **"Pedir orçamento no WhatsApp →"**
- Linha pequena embaixo: *Resposta rápida, direto comigo.*

---

## 13. Botões de WhatsApp (resumo)

Pontos estratégicos, todos pequenos e discretos:
1. Final da animação da hero (só aparece na Fase 4)
2. "Fale conosco" na navbar
3. Após a vitrine
4. CTA final

Além disso, um **botão flutuante** circular de ~48px (ícone WhatsApp em linha, fundo preto, borda fina off-white) no canto inferior direito, que **só aparece depois que a hero termina** (fade + slide suave) e se esconde quando o CTA final está visível. Nada de verde WhatsApp: mantenha o monocromático. Todos com `aria-label` descritivo.

---

## 14. Rodapé

Fundo preto, minimalista:
- Símbolo "N" + wordmark NEXORA STUDIO
- Slogan: Sites que impulsionam negócios
- Links: WhatsApp · contactisrael.dev22@gmail.com
- Ícone do **Instagram comentado no código** (`{/* TODO: adicionar Instagram */}`) para ativar depois
- Seletor PT | EN
- `© 2026 Nexora Studio. Todos os direitos reservados.`

---

## 15. Animações do restante do site

Contenção é a regra: o site é premium, não um parque de diversões.
- Títulos e eyebrows: fade-up com leve stagger (y: 24px → 0, opacity 0 → 1, 0.8s, `power3.out`) ao entrar na viewport.
- Mockups da vitrine: parallax leve (±40px).
- Cards: hover com zoom sutil e borda escurecendo.
- Linha do processo desenhada no scroll.
- **Sem** cursor customizado, **sem** partículas, **sem** efeitos 3D chamativos.
- Tudo desativado com `prefers-reduced-motion`.

---

## 16. Internacionalização (PT-BR / EN)

- `next-intl`, PT-BR como padrão em `/`, inglês em `/en`.
- Todos os textos em `messages/pt.json` e `messages/en.json`. Traduza todo o conteúdo deste prompt para inglês natural (não literal). Ex.: slogan → **"Websites that drive business"**.
- O seletor PT | EN mantém o usuário na mesma seção ao trocar de idioma.
- `hreflang` e `alternate` corretos para as duas versões.

---

## 17. SEO e performance

- Metadata por idioma. PT: title `Nexora Studio | Sites que impulsionam negócios`; description `Criação de sites profissionais, SEO e marketing digital para empresas no Brasil, na Europa e nos EUA. Peça seu orçamento pelo WhatsApp.`
- Open Graph com imagem 1200×630 gerada com a identidade (fundo preto, wordmark, slogan) via `next/og`.
- Favicon e ícones de app baseados no "N" (versão clara e escura, como no logo-system).
- `sitemap.xml` e `robots.txt` com o domínio placeholder `nexorastudio.com.br` (centralize em `lib/site.ts`).
- JSON-LD `ProfessionalService` / `Organization`.
- Imagens com `next/image`, `.webp`, lazy loading. Lighthouse alvo: 90+ em todas as categorias.
- HTML semântico, contraste AA, foco visível, navegação por teclado, `alt` em todas as imagens, link "Pular para o conteúdo".

---

## 18. Organização do código

```
app/[locale]/page.tsx        # monta as seções
app/[locale]/layout.tsx
components/brand/            # NSymbol.tsx, Wordmark.tsx (SVG)
components/sections/         # Hero, WhyWebsite, Services, Showcase, Process, About, FinalCta, Footer
components/ui/               # Button, WhatsAppButton, FloatingWhatsApp, LocaleSwitcher
lib/whatsapp.ts  lib/site.ts  lib/gsap.ts (registro de plugins + Lenis)
data/projects.ts
messages/pt.json  messages/en.json
public/brand/  public/projects/
```

Componentes de animação como Client Components (`'use client'`), com `useGSAP` (`@gsap/react`) e limpeza correta dos ScrollTriggers.

---

## 19. Critérios de pronto

- [ ] A hero reproduz exatamente as 4 fases descritas, suave a 60fps, no desktop e no mobile
- [ ] O botão da hero só aparece no fim da animação
- [ ] Versão `prefers-reduced-motion` funcionando
- [ ] Os 2 projetos reais com screenshots e links funcionando; 4 placeholders prontos em `data/projects.ts`
- [ ] Todos os botões de WhatsApp abrem `wa.me/5524981754835` com a mensagem certa em cada idioma
- [ ] PT-BR e EN completos, sem texto fixo no código
- [ ] Nenhuma cor fora da paleta; Manrope em todo o site
- [ ] Nenhuma estatística inventada
- [ ] Responsivo de 360px a 1920px, sem scroll horizontal
- [ ] `npm run build` sem erros; Lighthouse 90+

Ao terminar, rode o projeto, revise a hero rolando devagar do início ao fim, compare visualmente com `public/brand/brand-board.png` e ajuste o que estiver fora da identidade.
