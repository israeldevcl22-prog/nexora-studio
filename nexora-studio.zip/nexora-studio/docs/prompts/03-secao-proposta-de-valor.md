# Prompt — Nova seção persuasiva com janelas em perspectiva (Nexora Studio)

> Coloque este arquivo na raiz do projeto e diga ao Claude Code: *"Leia o PROMPT.md e crie a nova seção."*

---

## Contexto

O site da Nexora Studio já existe e está aprovado. **Não altere a hero** (animação, logos, estado final, botão), nem nenhuma outra seção. A tarefa é **criar uma seção nova**, logo depois da hero e antes de "Por que ter um site".

Objetivo da seção: depois da apresentação da marca, convencer o visitante em poucos segundos. Uma headline focada no resultado do cliente, uma descrição curta, um CTA forte e, ao lado, **janelas de navegador em perspectiva** mostrando sites reais. Isso mostra visualmente o tipo de trabalho do estúdio e prepara o terreno para o portfólio.

Ordem final das seções:
1. Hero (sem mudanças)
2. **Nova seção — Proposta de valor** ← criar
3. Por que ter um site
4. Serviços
5. Vitrine
6. Processo
7. Sobre
8. CTA final
9. Rodapé

---

## 1. Layout

- **Fundo preto** (`#0E0E0E`), contrastando com o off-white do fim da hero. A virada de cor marca a passagem da marca para o negócio.
- Altura mínima: `100vh` (desktop).
- **Desktop:** duas colunas. Esquerda (~45%) com o texto; direita (~55%) com as janelas em perspectiva, que podem "vazar" levemente para fora da borda direita da tela.
- **Mobile:** texto em cima, janelas embaixo (menores, só 2 janelas).
- Mantenha os detalhes discretos já usados nas outras seções (eyebrow, numeração editorial `02 / 09` no canto, cruzes de registro), adaptados ao fundo escuro (cinza `#3A3A3A`).
- Ao fundo, `logo-n-light.png` gigante a ~3% de opacidade, cortado pela borda, como nas outras seções.

## 2. Conteúdo (via `next-intl`, PT e EN)

**Eyebrow:** `NEXORA STUDIO —` / `NEXORA STUDIO —`

**Headline** (grande, Manrope 500–600, off-white, tracking levemente negativo, 2–3 linhas):
- PT: **Enquanto você não é encontrado, seu concorrente ganha espaço.**
- EN: **While no one can find you, your competitors gain ground.**

Dê ênfase visual a **"seu concorrente ganha espaço"** (por exemplo, essa parte em off-white e o início da frase em `#A7A3A0`, ou um reveal de máscara palavra a palavra ao entrar na tela). Use texto copiado exatamente, sem reescrever.

**Descrição** (2–3 linhas, `#A7A3A0`, largura máxima ~520px):
- PT: Seu negócio merece mais do que presença online. Merece um site que transmita confiança, valorize a sua marca e ajude a conquistar novas oportunidades.
- EN: Your business deserves more than just an online presence. It deserves a website that builds trust, elevates your brand and helps you win new opportunities.

**CTA principal** (o botão mais destacado do site; pill off-white, texto preto, ~56–64px de altura, seta `→`; leva ao WhatsApp com o helper existente em `lib/whatsapp.ts`):
- PT: **Vamos criar seu próximo site →** (texto exato)
- EN: **Let's build your next website →**

Hover: a seta desliza alguns pixels para a direita e o botão ganha um brilho metálico sutil passando (mesmo gradiente da marca).

**Link secundário** discreto, ao lado ou abaixo do botão (sublinhado fino, rola até a vitrine com Lenis):
- PT: Ver projetos
- EN: See projects

**Linha de confiança** (pequena, caixa alta, tracking largo, `#A7A3A0`, separada por `·`), **só com fatos verdadeiros**:
- PT: ATENDIMENTO DIRETO COM O FUNDADOR · BRASIL, EUROPA E EUA · RESPOSTA RÁPIDA
- EN: DIRECT CONTACT WITH THE FOUNDER · BRAZIL, EUROPE & USA · FAST REPLIES

Não invente números (clientes, anos, porcentagens).

## 3. As janelas de navegador em perspectiva

Três janelas de navegador sobrepostas em **profundidades diferentes**, com aparência levemente 3D (CSS 3D, sem Three.js).

### Visual de cada janela
- Construída em HTML/CSS: barra superior escura (`#1A1A1A`) com três pontos cinza (sem vermelho/amarelo/verde), barra de endereço arredondada com o domínio em cinza pequeno.
- Cantos arredondados (12px), borda fina (`1px rgba(255,255,255,0.08)`), sombra longa e suave para separar as camadas.
- Conteúdo: **screenshot real** do site (os mesmos usados na vitrine, em `public/projects/`; se faltar algum, gere com Playwright em 1440×900 e salve em `.webp`).
- Uma borda superior com brilho metálico muito sutil (gradiente da marca).

### As três janelas
| Camada | Site | Barra de endereço | Posição |
|---|---|---|---|
| Frente | Liga Forte | `liga-forte.vercel.app` | Maior, mais à frente e mais abaixo |
| Meio | LA Sanduicheria | `la-sanduicheria-site.vercel.app` | Média, deslocada para cima e para a direita |
| Fundo | O próprio site da Nexora (hero final, com o wordmark) | `nexorastudio.com.br` | Menor, mais ao fundo, levemente desfocada (`blur(1px)`) e mais escura |

### Perspectiva
- Contêiner com `perspective: 1800px`.
- Grupo inteiro com `rotateY(-18deg) rotateX(6deg)`, como se as janelas estivessem numa mesa vista de lado.
- Cada janela com `translateZ` diferente (frente ~120px, meio ~0, fundo ~-160px) e leve deslocamento X/Y para criar a cascata.

### Movimento (sutil, sempre)
- **Entrada:** quando a seção entra na tela, as janelas sobem e aparecem em sequência (fundo → meio → frente), `y: 60 → 0`, `opacity: 0 → 1`, stagger de 0.15s, `power3.out`.
- **Scroll (parallax de profundidade):** com GSAP ScrollTrigger (`scrub: 1`), cada camada se move em velocidade diferente enquanto a seção passa: frente ~-80px, meio ~-40px, fundo ~-15px em Y. A rotação do grupo diminui levemente (`rotateY -18° → -10°`), como se as janelas virassem para o visitante.
- **Saída / transição para o portfólio:** no fim da seção, as janelas continuam subindo suavemente e ganham um pouco de escala, levando o olhar para baixo, para a próxima seção.
- **Mouse (só desktop, opcional):** inclinação extra de no máximo ±3°, seguindo o cursor, com suavização (`gsap.quickTo`).
- **Hover em uma janela:** ela avança um pouco (`translateZ +20px`) e mostra o rótulo `Ver projeto →`. Clique rola até o card correspondente na vitrine (não abre link externo aqui).
- Nada de rotações exageradas, giros ou efeitos chamativos. O tom é premium e calmo.

### Acessibilidade e desempenho
- As janelas são decorativas para leitores de tela (`aria-hidden`), exceto o link de hover, que precisa de `aria-label`.
- Imagens com `next/image`, `.webp`, `sizes` corretos e lazy loading.
- Só animar `transform` e `opacity`. Usar `will-change` apenas durante a animação.
- `prefers-reduced-motion`: janelas estáticas na posição final, sem parallax, sem inclinação pelo mouse.
- Mobile: só 2 janelas (Liga Forte e LA Sanduicheria), perspectiva mais suave (`rotateY -8deg`), sem efeito de mouse.

## 4. Organização

- Componente novo: `components/sections/ValueProposition.tsx`.
- Subcomponente reutilizável: `components/ui/BrowserWindow.tsx` (props: `src`, `alt`, `url`, `className`).
- Textos em `messages/pt.json` e `messages/en.json`, na chave `valueProposition`.
- Atualize a numeração editorial das outras seções (agora são 9 seções: `03 / 09`, `04 / 09`...).
- Se houver navbar com links de âncora, não é preciso link para esta seção.

## 5. Pronto quando

- [ ] Hero e demais seções sem nenhuma alteração (exceto a numeração editorial)
- [ ] Nova seção logo após a hero, fundo preto, headline, descrição, CTA grande e linha de confiança
- [ ] Três janelas de navegador em perspectiva com os sites reais, em profundidades diferentes
- [ ] Parallax sutil no scroll, entrada em sequência e transição suave para a próxima seção
- [ ] CTA abre o WhatsApp com a mensagem certa em PT e EN
- [ ] Versão mobile e `prefers-reduced-motion` funcionando
- [ ] 60fps e `npm run build` sem erros

Ao terminar, rode o site, role devagar da hero até a vitrine e confira se a passagem hero → nova seção → resto do site parece natural e premium.
