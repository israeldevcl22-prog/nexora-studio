# Prompt de ajustes — Site Nexora Studio (para Claude Code)

> **Antes de rodar:** copie a pasta `brand/` deste pacote para `public/brand/` do projeto (substitua a antiga). Depois, abra o Claude Code na pasta do projeto e diga: *"Leia o PROMPT.md e aplique todas as mudanças."*
>
> Referências incluídas:
>
> ![Brand board](brand/brand-board.png)
> ![Sistema de logos (PNG transparente)](brand/logo-system-transparent.png)

---

## 0. Contexto

O site da Nexora Studio já existe neste projeto (Next.js + Tailwind + GSAP + Lenis + next-intl). **Não recrie o projeto.** Aplique apenas as mudanças abaixo, mantendo tudo o que já funciona (textos, i18n PT/EN, WhatsApp, vitrine, SEO).

São 4 mudanças, em ordem de prioridade:
1. Usar os **logos oficiais exatos** (PNG) em todo o site
2. Refazer o **final da animação da hero** para ficar fiel ao brand board
3. Colocar um **celular com o site** no CTA final
4. Adicionar **detalhes discretos** nas seções off-white

Antes de começar, abra e analise `public/brand/brand-board.png` e `public/brand/logo-system-transparent.png`.

---

## 1. Logos oficiais — regra absoluta

Os logos atuais foram redesenhados em SVG e **não estão fiéis**. Substitua todos pelos PNGs oficiais.

### Arquivos em `public/brand/`
| Arquivo | O que é | Onde usar |
|---|---|---|
| `logo-wordmark.png` | NEXORA® + STUDIO, preto, com o N cromado | Fundos claros: hero final, navbar sobre fundo claro |
| `logo-wordmark-light.png` | Mesma peça em branco | Fundos escuros: CTA final, rodapé, navbar sobre fundo escuro |
| `logo-n.png` | Símbolo **N preto com a haste diagonal cromada** | Hero (início), marcas d'água, placeholders da vitrine, foto do "Sobre" |
| `logo-n-light.png` | Símbolo N em branco com a haste cromada | Fundos escuros |
| `logo-horizontal.png` / `logo-horizontal-light.png` | N + divisor + NEXORA STUDIO | Navbar (opcional) e rodapé |
| `icon-light.png` / `icon-dark.png` | Ícones de app (claro/escuro) | Favicon, apple-touch-icon, ícone do botão flutuante |
| `logo-system-transparent.png` | Folha original com todas as versões | Só referência |
| `brand-board.png` | Brand board completo | Só referência |

### Regras
- **Nunca redesenhe, vetorize, recolora, distorça ou "melhore" os logos.** Use os PNGs exatamente como estão, com `next/image`, mantendo a proporção original (`width`/`height` reais do arquivo, `object-contain`).
- Apague os componentes SVG antigos (`NSymbol`, `Wordmark` ou equivalentes) ou faça-os renderizar os PNGs.
- O "N" é **preto com o detalhe cromado no meio da haste diagonal**. É exatamente o de `logo-n.png`. Não use uma letra N digitada em fonte nenhuma.
- Escolha sempre a variante certa para o fundo (preta em fundo claro, `-light` em fundo escuro). A navbar troca de variante conforme o fundo da seção atrás dela.
- Gere favicon e `apple-touch-icon` a partir de `icon-light.png` / `icon-dark.png` (use `sharp` para redimensionar; não altere o desenho).
- Para dar vida ao cromado sem alterar o logo, você pode passar um **reflexo de luz** por cima: uma `div` com `linear-gradient` branco translúcido, recortada com `mask-image: url(/brand/logo-n.png)` (ou do wordmark), animando o `background-position`. O logo em si permanece intocado.

---

## 2. Hero — novo final fiel ao brand board

O estado final da hero deve ser **praticamente idêntico ao bloco superior esquerdo do `brand-board.png`**:

- Fundo **off-white** (`#F8F6F3`), não preto
- Uma **sombra de luz de janela diagonal muito suave** no canto superior esquerdo (gradiente/feixes difusos em cinza claro, opacidade baixa), como no brand board
- `logo-wordmark.png` centralizado (com o ®), grande (~min(60vw, 720px))
- Abaixo, a frase **SITES QUE IMPULSIONAM NEGÓCIOS** em caixa alta, Manrope, letter-spacing ~0.35em, cor `#A7A3A0`, tamanho pequeno
- Botão pequeno de WhatsApp "Pedir orçamento →" (pill preta, texto off-white), aparecendo só no fim
- Indicador `ROLE` com linha fina embaixo

### Nova sequência (pinned ~300vh desktop / ~180vh mobile, `scrub: 1`)

**Estado inicial (0%)**
- Fundo off-white. O **`logo-n.png` enorme** (~70vh de altura), centralizado, com opacidade baixa (~0.12) — grande e discreto.
- `ROLE PARA DESCOBRIR` pequeno embaixo (cor `#A7A3A0`, sem cores; corrija o texto atual que está colorido).

**Fase 1 (0% → 30%) — o N ganha presença**
- O N sobe de opacidade até 1 e reduz levemente de escala (1.1 → 1). O reflexo cromado (máscara da seção 1) passa uma vez pela haste diagonal.

**Fase 2 (30% → 65%) — a faixa escura atravessa**
- Uma **faixa diagonal escura** (`#0E0E0E` → `#3A3A3A`, no mesmo ângulo da haste do N) entra por um canto e **atravessa a tela inteira, saindo pelo canto oposto**. Use um elemento rotacionado com `transform` ou `clip-path: polygon(...)` animado.
- Enquanto a faixa cobre o centro, troque o conteúdo por trás dela: o N grande sai e o **`logo-wordmark.png`** fica no lugar. Quando a faixa termina de passar, o wordmark já está revelado — a sensação é que a faixa "pintou" a marca na tela.
- Uma borda fina com brilho metálico acompanha a aresta da faixa.

**Fase 3 (65% → 85%) — refinamento**
- O wordmark faz um leve ajuste (scale 1.04 → 1, blur 4px → 0).
- A luz de janela diagonal surge suavemente no fundo.
- O reflexo cromado passa uma vez pelo N do wordmark.

**Fase 4 (85% → 100%) — frase e CTA**
- **SITES QUE IMPULSIONAM NEGÓCIOS** aparece com reveal de máscara (de baixo para cima).
- O botão "Pedir orçamento →" e a navbar completa entram com fade.

### Requisitos
- Como o wordmark é PNG, revele-o com `clip-path`/máscara, `opacity`, `scale` e `filter: blur` — não tente separar letras.
- Navbar durante a hero: variante preta do logo (fundo off-white); some sob a faixa escura e volta no fim.
- `prefers-reduced-motion`: sem pin, mostra direto o estado final.
- 60fps; só `transform`, `opacity`, `clip-path`, `filter` leve.

---

## 3. CTA final — celular com o site

Na seção "Vamos tirar o seu site do papel?", **substitua o bloco abstrato da direita** (as linhas/gradientes cinzas e o N solto) por um **mockup de celular** mostrando o próprio site da Nexora, como o celular do canto inferior direito do brand board.

- Construa o celular em HTML/CSS: corpo preto com cantos bem arredondados, borda fina metálica (gradiente cinza), ilha dinâmica, botões laterais sutis, sombra suave e longa.
- **Tela:** um screenshot real da versão mobile do site (gere com Playwright em 390×844, página inteira, salve em `public/projects/nexora-mobile.webp`). A tela faz um **auto-scroll lento e contínuo** pela página (loop suave, ~25s), mostrando hero com o logo, serviços e vitrine.
- Inclinação leve (rotateZ -6deg, levemente em perspectiva), com parallax suave ao rolar a página.
- Atrás do celular, um brilho radial muito sutil e o `logo-n-light.png` gigante a 4% de opacidade, cortado pela borda da seção.
- No mobile, o celular vai para baixo do texto, menor e sem inclinação.
- Use `logo-wordmark-light.png` no topo do texto desta seção (no lugar do wordmark atual).
- Com `prefers-reduced-motion`, a tela fica parada no topo.

---

## 4. Seções off-white — detalhes discretos

As seções claras (Por que ter um site, Serviços, Processo) estão cruas demais. Mantenha o minimalismo, mas adicione **camadas sutis** de acabamento editorial, como no brand board. Use **todos** os itens abaixo, sempre com baixíssimo contraste:

1. **Grade de colunas**: linhas verticais de 1px em `#E5E2DE` com ~40% de opacidade, alinhadas ao grid do conteúdo (4 colunas desktop, 2 mobile), ocupando a altura da seção.
2. **Cruzes de registro**: pequenos "+" (10px, traço 1px, `#A7A3A0` a 50%) nos cantos de cada seção, como marcas de impressão.
3. **Numeração editorial**: no canto superior direito de cada seção, `02 / 08`, `03 / 08`... em caixa alta pequena, tracking largo, `#A7A3A0`.
4. **N marca d'água**: `logo-n.png` gigante (~120vh) a **3–4% de opacidade**, cortado pela borda lateral em uma ou duas seções (alterne esquerda/direita). Parallax bem lento.
5. **Luz de janela**: o mesmo feixe de luz diagonal suave da hero em uma das seções, para dar profundidade.
6. **Textura de papel**: ruído finíssimo (SVG `feTurbulence` ou PNG de noise) a 2–3% de opacidade sobre os fundos off-white, para não parecer branco digital chapado.
7. **Processo**: além da linha que se desenha no scroll, os círculos de cada passo ficam preenchidos de preto quando a linha os alcança.
8. **Serviços**: cards com fundo levemente mais claro que a seção (`#FBFAF8`), borda fina e uma sombra interna quase imperceptível, como no brand board.

Nada disso pode competir com o conteúdo. Se algo chamar atenção, reduza a opacidade.

---

## 5. Outros ajustes

- Rodapé e "Sobre": troque qualquer N/wordmark antigo pelas versões `-light`.
- Placeholders da vitrine: use `logo-n-light.png` centralizado (a 30% de opacidade) em vez do N antigo.
- Botão flutuante do WhatsApp e o botão redondo com "N" no canto inferior esquerdo: se o botão com "N" for o indicador do Next.js (dev tools), ignore; ele não aparece em produção.

---

## 6. Critérios de pronto

- [ ] Nenhum logo redesenhado ou digitado: todos são os PNGs oficiais, na variante certa para o fundo
- [ ] Estado final da hero idêntico ao topo do brand board (off-white, wordmark preto com ®, frase em cinza, luz de janela)
- [ ] A faixa escura atravessa a tela e revela a marca, suave a 60fps
- [ ] CTA final com celular mostrando o próprio site em auto-scroll
- [ ] Seções off-white com os detalhes discretos, sem poluir
- [ ] Favicon e ícones a partir de `icon-light.png` / `icon-dark.png`
- [ ] `prefers-reduced-motion` funcionando
- [ ] PT/EN, WhatsApp e vitrine continuam funcionando
- [ ] `npm run build` sem erros

Ao terminar, rode o site, role a hero devagar do início ao fim e compare lado a lado com o topo de `public/brand/brand-board.png`. Ajuste até ficar fiel.
