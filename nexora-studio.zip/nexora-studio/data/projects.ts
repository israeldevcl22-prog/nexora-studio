export type ProjectStatus = "live" | "placeholder";

type Localized = { pt: string; en: string };

export type Project = {
  id: string;
  status: ProjectStatus;
  name: Localized;
  sector: Localized;
  description?: Localized;
  url?: string;
  /** Screenshots in /public/projects (desktop 1440×900, mobile 390×844). */
  images?: { desktop: string; mobile: string };
  /** Mockup shown in the card. */
  device: "laptop" | "phone";
};

export const projects: Project[] = [
  {
    id: "liga-forte",
    status: "live",
    name: { pt: "Liga Forte", en: "Liga Forte" },
    sector: { pt: "Indústria", en: "Manufacturing" },
    description: {
      pt: "Site institucional focado em gerar orçamentos pelo WhatsApp e ser encontrado no Google.",
      en: "Corporate website built to generate WhatsApp quote requests and get found on Google.",
    },
    url: "https://liga-forte.vercel.app",
    images: {
      desktop: "/projects/liga-forte-desktop.webp",
      mobile: "/projects/liga-forte-mobile.webp",
    },
    device: "laptop",
  },
  {
    id: "la-sanduicheria",
    status: "live",
    name: { pt: "LA Sanduicheria", en: "LA Sanduicheria" },
    sector: { pt: "Gastronomia", en: "Food & Beverage" },
    description: {
      pt: "Cardápio digital com identidade própria e pedidos direto pelo WhatsApp.",
      en: "Digital menu with its own identity and orders straight through WhatsApp.",
    },
    url: "https://la-sanduicheria-site.vercel.app",
    images: {
      desktop: "/projects/la-sanduicheria-desktop.webp",
      mobile: "/projects/la-sanduicheria-mobile.webp",
    },
    device: "laptop",
  },
  {
    id: "clinica",
    status: "placeholder",
    name: { pt: "Clínica", en: "Clinic" },
    sector: { pt: "Saúde", en: "Healthcare" },
    device: "laptop",
  },
  {
    id: "advocacia",
    status: "placeholder",
    name: { pt: "Escritório de advocacia", en: "Law firm" },
    sector: { pt: "Jurídico", en: "Legal" },
    device: "laptop",
  },
  {
    id: "loja-online",
    status: "placeholder",
    name: { pt: "Loja online", en: "Online store" },
    sector: { pt: "E-commerce", en: "E-commerce" },
    device: "phone",
  },
  {
    id: "academia",
    status: "placeholder",
    name: { pt: "Academia", en: "Gym" },
    sector: { pt: "Fitness", en: "Fitness" },
    device: "laptop",
  },
];
