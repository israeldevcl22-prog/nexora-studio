# Nexora Studio

**Sites que impulsionam negócios.**

Site portfólio da Nexora Studio, estúdio de desenvolvimento web e marketing digital. Bilíngue (PT-BR e EN), com animação de abertura no scroll, vitrine de projetos e pedidos de orçamento direto pelo WhatsApp.

## Stack

- [Next.js](https://nextjs.org) (App Router) + TypeScript
- [Tailwind CSS](https://tailwindcss.com)
- [GSAP](https://gsap.com) + ScrollTrigger (animações) e [Lenis](https://lenis.darkroom.engineering) (scroll suave)
- [next-intl](https://next-intl.dev) (português em `/`, inglês em `/en`)
- Fonte Manrope via `next/font`
- Hospedagem na [Vercel](https://vercel.com)

## Rodar no seu computador

Precisa do [Node.js](https://nodejs.org) 20 ou mais recente.

```bash
npm install
npm run dev
```

Abra http://localhost:3000 (português) ou http://localhost:3000/en (inglês).

Outros comandos:

| Comando | O que faz |
|---|---|
| `npm run build` | Gera a versão de produção (é o que a Vercel roda) |
| `npm run start` | Roda a versão de produção gerada pelo build |
| `npm run lint` | Procura problemas no código |

## Estrutura de pastas

```
app/[locale]/        páginas e metadados (SEO) de cada idioma
app/og/              imagem de compartilhamento (Open Graph)
components/sections/ seções da página (Hero, Proposta, Serviços, Vitrine…)
components/ui/       peças reutilizáveis (botões, navbar, janelas, celular…)
components/brand/    logos oficiais e detalhes de identidade visual
data/projects.ts     projetos da vitrine
messages/            textos em português (pt.json) e inglês (en.json)
lib/                 endereço do site, link do WhatsApp, GSAP/Lenis
public/brand/        logos oficiais (PNG)
public/projects/     capturas de tela dos projetos
scripts/             utilitários (capturas de tela, ícones)
docs/                histórico de prompts e referências da marca
```

## Trocar os projetos da vitrine

Edite `data/projects.ts`. Cada projeto tem nome, setor e descrição em PT e EN, link e imagens.

- `status: "live"` mostra a captura de tela e o botão "Ver site".
- `status: "placeholder"` mostra a tela neutra com o selo "Em breve".

Para gerar capturas de um site novo, adicione-o em `scripts/screenshots.mjs` e rode:

```bash
npx playwright install chromium
node scripts/screenshots.mjs
```

## Editar os textos

Todos os textos ficam em `messages/pt.json` (português) e `messages/en.json` (inglês). Altere sempre os dois arquivos, mantendo as mesmas chaves.

O número do WhatsApp e o e-mail ficam em `lib/site.ts`; as mensagens automáticas do WhatsApp, em `lib/whatsapp.ts`.

## Deploy (Vercel)

1. Entre em [vercel.com](https://vercel.com) com a conta do GitHub.
2. **Add New → Project** e importe o repositório `nexora-studio`.
3. A Vercel detecta Next.js sozinha: não mude o build command nem o output.
4. Clique em **Deploy**.

Depois disso, cada `git push` na branch `main` publica o site automaticamente.

### Endereço do site

Enquanto não houver domínio próprio, o site usa o endereço `.vercel.app` que a Vercel fornece, sem configurar nada.

Quando tiver um domínio próprio:

1. Na Vercel: **Settings → Domains** e adicione o domínio (siga as instruções de DNS que aparecem).
2. Em **Settings → Environment Variables**, crie `NEXT_PUBLIC_SITE_URL` com o endereço completo (ex.: `https://nexorastudio.com.br`).
3. Faça um novo deploy (**Deployments → Redeploy**).

Veja `.env.example`. Nunca envie um arquivo `.env` com valores reais para o GitHub.

## Contato

- WhatsApp: [+55 24 98175-4835](https://wa.me/5524981754835)
- E-mail: [contactisrael.dev22@gmail.com](mailto:contactisrael.dev22@gmail.com)

---

© 2026 Nexora Studio. Todos os direitos reservados.
