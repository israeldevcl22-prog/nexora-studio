import createMiddleware from "next-intl/middleware";
import { routing } from "./i18n/routing";

export default createMiddleware(routing);

export const config = {
  // Skip API, Next internals, metadata routes and files with an extension
  matcher: ["/((?!api|og|_next|_vercel|apple-icon|.*\\..*).*)"],
};
