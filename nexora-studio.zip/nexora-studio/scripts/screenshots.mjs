// Captures the live projects for the showcase.
// Usage: node scripts/screenshots.mjs   (needs: npx playwright install chromium)
import { chromium } from "playwright";
import sharp from "sharp";
import path from "node:path";

const OUT = path.resolve("public/projects");

const sites = [
  { id: "liga-forte", url: "https://liga-forte.vercel.app" },
  { id: "la-sanduicheria", url: "https://la-sanduicheria-site.vercel.app" },
];

const viewports = {
  desktop: { width: 1440, height: 900, deviceScaleFactor: 1, isMobile: false },
  mobile: { width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
};

const browser = await chromium.launch();
for (const site of sites) {
  for (const [kind, vp] of Object.entries(viewports)) {
    const { width, height, ...rest } = vp;
    const ctx = await browser.newContext({ viewport: { width, height }, ...rest, reducedMotion: "reduce" });
    const page = await ctx.newPage();
    await page.goto(site.url, { waitUntil: "networkidle", timeout: 60_000 });
    await page.waitForTimeout(2500); // let intro animations / fonts settle
    const png = await page.screenshot({ type: "png" });
    const file = path.join(OUT, `${site.id}-${kind}.webp`);
    await sharp(png)
      .resize({ width: kind === "desktop" ? 1440 : 780 })
      .webp({ quality: 80, effort: 6 })
      .toFile(file);
    console.log("saved", file);
    await ctx.close();
  }
}
await browser.close();
