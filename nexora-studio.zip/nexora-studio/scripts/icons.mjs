// Favicons + apple-touch-icon from the official app icons (resize only).
// Usage: node scripts/icons.mjs
import sharp from "sharp";
import fs from "node:fs";

const SRC = "public/brand";
const OUT = "public/icons";
fs.mkdirSync(OUT, { recursive: true });

const transparent = { r: 0, g: 0, b: 0, alpha: 0 };

for (const tone of ["light", "dark"]) {
  for (const size of [32, 192, 512]) {
    await sharp(`${SRC}/icon-${tone}.png`)
      .resize(size, size, { fit: "contain", background: transparent })
      .png()
      .toFile(`${OUT}/icon-${tone}-${size}.png`);
  }
}

// iOS masks the corners itself, so the tile is flattened onto its own color.
await sharp(`${SRC}/icon-dark.png`)
  .resize(180, 180, { fit: "contain", background: transparent })
  .flatten({ background: "#0E0E0E" })
  .png()
  .toFile(`${OUT}/apple-touch-icon.png`);

console.log("icons written to", OUT);
