// Captures of the Nexora site itself: full-page mobile (phone mockup of the
// final CTA) and desktop hero (browser window of the value-proposition
// section). Run against a production server:
//   npm run build && npm run start -- -p 3001
//   node scripts/self-screenshot.mjs http://localhost:3001/
import { chromium } from "playwright";
import sharp from "sharp";
import fs from "node:fs";

const url = process.argv[2] ?? "http://localhost:3001/";
const WIDTH = 390;
const SCALE = 1.5; // retina-ish without a huge file

const browser = await chromium.launch();
const ctx = await browser.newContext({
  viewport: { width: WIDTH, height: 844 },
  deviceScaleFactor: SCALE,
  isMobile: true,
  hasTouch: true,
  // Static final states, no pin: the page reads top to bottom.
  reducedMotion: "reduce",
});
const page = await ctx.newPage();
await page.goto(url, { waitUntil: "networkidle" });
// Hide fixed UI so it doesn't float in the middle of the capture.
await page.addStyleTag({ content: "header, #mobile-menu, a[aria-label*='WhatsApp'].fixed { display: none !important; }" });
await page.evaluate(async () => {
  // Trigger lazy images.
  for (let y = 0; y < document.body.scrollHeight; y += 600) {
    window.scrollTo(0, y);
    await new Promise((r) => setTimeout(r, 120));
  }
  window.scrollTo(0, 0);
});
await page.waitForTimeout(800);
// Hero → services → showcase is what the phone needs to show.
const bottom = await page.evaluate(() => {
  const el = document.getElementById("projetos");
  return Math.ceil(el.getBoundingClientRect().bottom + window.scrollY);
});
const png = await page.screenshot({ fullPage: true, type: "png", clip: { x: 0, y: 0, width: WIDTH, height: bottom } });
await browser.close();

// WebP caps at 16383px per side.
const width = Math.min(Math.round(WIDTH * SCALE), Math.floor((16000 / bottom) * WIDTH));
const out = sharp(png).resize({ width }).webp({ quality: 74, effort: 6 });
const info = await out.toFile("public/projects/nexora-mobile.webp");
fs.writeFileSync(
  "data/nexora-mobile.json",
  JSON.stringify({ width: info.width, height: info.height }, null, 2) + "\n"
);
console.log("saved public/projects/nexora-mobile.webp", info.width, "x", info.height, `${Math.round(info.size / 1024)} KB`);

// Desktop 1440×900 of the hero's final state, for the back browser window of
// the value-proposition section.
{
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: "reduce" });
  const page = await ctx.newPage();
  await page.goto(url, { waitUntil: "networkidle" });
  await page.addStyleTag({ content: "a[aria-label*='WhatsApp'].fixed, nextjs-portal { display: none !important; }" });
  await page.waitForTimeout(800);
  const shot = await page.screenshot({ type: "png" });
  await browser.close();
  const d = await sharp(shot).webp({ quality: 80, effort: 6 }).toFile("public/projects/nexora-desktop.webp");
  console.log("saved public/projects/nexora-desktop.webp", d.width, "x", d.height, `${Math.round(d.size / 1024)} KB`);
}
