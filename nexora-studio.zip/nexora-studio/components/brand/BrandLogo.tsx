import Image, { getImageProps } from "next/image";
import type { CSSProperties } from "react";

/**
 * Official Nexora logos — the PNG files in /public/brand are the source of
 * truth. Never redraw them: this component only picks the right file for the
 * background and keeps the original aspect ratio.
 */
export const LOGOS = {
  wordmark: { dark: "/brand/logo-wordmark.png", light: "/brand/logo-wordmark-light.png", width: 812, height: 182 },
  n: { dark: "/brand/logo-n.png", light: "/brand/logo-n-light.png", width: 191, height: 186 },
  horizontal: { dark: "/brand/logo-horizontal.png", light: "/brand/logo-horizontal-light.png", width: 528, height: 110 },
  // App icon: black tile for light backgrounds, white tile for dark ones.
  icon: { dark: "/brand/icon-dark.png", light: "/brand/icon-light.png", width: 273, height: 271 },
} as const;

export type LogoKind = keyof typeof LOGOS;

type Props = {
  kind: LogoKind;
  /** dark = black logo for light backgrounds, light = white logo for dark backgrounds. */
  tone?: "dark" | "light";
  alt?: string;
  className?: string;
  style?: CSSProperties;
  priority?: boolean;
  sizes?: string;
};

export function BrandLogo({
  kind,
  tone = "dark",
  alt = "Nexora Studio",
  className = "",
  style,
  priority,
  sizes = "(min-width: 768px) 720px, 80vw",
}: Props) {
  const logo = LOGOS[kind];
  return (
    <Image
      src={logo[tone]}
      width={logo.width}
      height={logo.height}
      alt={alt}
      priority={priority}
      sizes={sizes}
      draggable={false}
      className={`h-auto max-w-full object-contain select-none ${className}`}
      style={style}
    />
  );
}

/**
 * A light reflection travelling over a logo, clipped to the logo's own shape
 * with mask-image. The logo underneath is untouched. Animate `--sheen-x`
 * (or background-position) from -100% to 200%.
 */
export function ChromeSheen({
  kind,
  tone = "dark",
  className = "",
}: {
  kind: LogoKind;
  tone?: "dark" | "light";
  className?: string;
}) {
  const logo = LOGOS[kind];
  // Same optimized (webp/avif, alpha kept) file next/image serves, not the raw PNG.
  const { src } = getImageProps({
    src: logo[tone],
    width: Math.min(logo.width, 720),
    height: Math.round((Math.min(logo.width, 720) * logo.height) / logo.width),
    alt: "",
  }).props;
  return (
    <span
      aria-hidden="true"
      data-sheen
      className={`chrome-sheen pointer-events-none absolute inset-0 ${className}`}
      style={{
        WebkitMaskImage: `url("${src}")`,
        maskImage: `url("${src}")`,
      }}
    />
  );
}
