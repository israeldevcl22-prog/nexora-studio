import { BrandLogo } from "./BrandLogo";
import { WindowLight } from "./WindowLight";

type Props = {
  /** Editorial index, e.g. 2 → "02 / 08". */
  index: number;
  total?: number;
  /** Giant N watermark bleeding off one side. */
  watermark?: "left" | "right";
  /** Soft diagonal window light. */
  light?: boolean;
  /** Dark sections use #3A3A3A details and no paper grain. */
  tone?: "light" | "dark";
};

const pad = (n: number) => String(n).padStart(2, "0");

/**
 * Low-contrast editorial finish for off-white sections: column grid,
 * registration marks, section index, N watermark, window light and paper grain.
 * The parent section must be `relative overflow-hidden`; content sits at z-10.
 */
export function SectionDecor({ index, total = 9, watermark, light, tone = "light" }: Props) {
  const dark = tone === "dark";
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 select-none">
      {light && <WindowLight className="opacity-70" corner={watermark === "left" ? "right" : "left"} />}

      {watermark && (
        <div
          className={`absolute top-1/2 -translate-y-1/2 ${
            watermark === "left" ? "left-0 -translate-x-[42%]" : "right-0 translate-x-[42%]"
          }`}
        >
          <div data-parallax-slow className="will-change-transform">
            <BrandLogo kind="n" tone={dark ? "light" : "dark"} alt="" sizes="120vh" className="h-[120vh] w-auto opacity-[0.03]" />
          </div>
        </div>
      )}

      {/* Column grid aligned to the content container */}
      <div className="absolute inset-y-0 right-5 left-5 md:right-10 md:left-10">
       <div className="mx-auto grid h-full max-w-[1320px] grid-cols-2 md:grid-cols-4">
        {[
          "",
          "border-r md:border-r-0", // last column on mobile
          "hidden md:block",
          "hidden md:block md:border-r", // last column on desktop
        ].map((extra, i) => (
          <span key={i} className={`border-l ${dark ? "border-cinza-escuro/40" : "border-cinza-claro/40"} ${extra}`} />
        ))}
       </div>
      </div>

      {/* Registration marks */}
      <Cross dark={dark} className="top-5 left-5" />
      <Cross dark={dark} className="top-5 right-5" />
      <Cross dark={dark} className="bottom-5 left-5" />
      <Cross dark={dark} className="right-5 bottom-5" />

      {/* Editorial index */}
      <span className={`absolute top-8 right-12 text-[10px] font-semibold tracking-[0.35em] tabular-nums md:right-16 ${dark ? "text-cinza-escuro" : "text-cinza-medio"}`}>
        {pad(index)} / {pad(total)}
      </span>

      {!dark && <div className="paper-grain absolute inset-0" />}
    </div>
  );
}

function Cross({ className, dark }: { className: string; dark?: boolean }) {
  return (
    <svg
      viewBox="0 0 10 10"
      className={`absolute size-[10px] ${dark ? "text-cinza-escuro" : "text-cinza-medio/50"} ${className}`}
      fill="none"
      stroke="currentColor"
      strokeWidth="1"
    >
      <path d="M5 0V10M0 5H10" />
    </svg>
  );
}
