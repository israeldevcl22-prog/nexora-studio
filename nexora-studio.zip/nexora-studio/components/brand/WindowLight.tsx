/**
 * Soft diagonal window-light shadow, as in the top-left of the brand board.
 * Static, blurred beams at very low opacity — only its opacity is ever animated.
 */
export function WindowLight({
  className = "",
  corner = "left",
}: {
  className?: string;
  corner?: "left" | "right";
}) {
  return (
    <div
      aria-hidden="true"
      className={`window-light pointer-events-none absolute inset-0 overflow-hidden ${className}`}
    >
      <div
        className={`absolute -top-[30%] h-[120%] w-[85%] blur-[38px] ${
          corner === "left" ? "-left-[25%] rotate-[-32deg]" : "-right-[25%] rotate-[32deg]"
        }`}
        style={{
          background:
            "repeating-linear-gradient(90deg, rgba(167,163,160,0) 0px, rgba(167,163,160,0) 70px, rgba(167,163,160,0.32) 110px, rgba(167,163,160,0.32) 190px, rgba(167,163,160,0) 230px, rgba(167,163,160,0) 300px)",
          maskImage: "linear-gradient(180deg, #000 0%, rgba(0,0,0,0.6) 45%, transparent 85%)",
          WebkitMaskImage: "linear-gradient(180deg, #000 0%, rgba(0,0,0,0.6) 45%, transparent 85%)",
        }}
      />
    </div>
  );
}
