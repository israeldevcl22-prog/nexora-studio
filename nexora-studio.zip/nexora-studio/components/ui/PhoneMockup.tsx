import Image from "next/image";
import shot from "@/data/nexora-mobile.json";

/** Screen height of the phone in screenshot pixels (390×844 viewport). */
const SCREEN_RATIO = 844 / 390;

/**
 * HTML/CSS phone showing a real full-page capture of this site that scrolls
 * slowly on its own (CSS animation, paused by prefers-reduced-motion).
 */
export function PhoneMockup({ alt, className = "" }: { alt: string; className?: string }) {
  // How far the image must travel so its bottom meets the bottom of the screen.
  const screenH = shot.width * SCREEN_RATIO;
  const scrollEnd = `${(-(1 - screenH / shot.height) * 100).toFixed(3)}%`;

  return (
    <div className={`relative ${className}`}>
      {/* Side buttons */}
      <span aria-hidden="true" className="absolute top-[18%] -left-[3px] h-[6%] w-[3px] rounded-l-sm bg-[linear-gradient(90deg,#3A3A3A,#A7A3A0)]" />
      <span aria-hidden="true" className="absolute top-[27%] -left-[3px] h-[10%] w-[3px] rounded-l-sm bg-[linear-gradient(90deg,#3A3A3A,#A7A3A0)]" />
      <span aria-hidden="true" className="absolute top-[39%] -left-[3px] h-[10%] w-[3px] rounded-l-sm bg-[linear-gradient(90deg,#3A3A3A,#A7A3A0)]" />
      <span aria-hidden="true" className="absolute top-[30%] -right-[3px] h-[14%] w-[3px] rounded-r-sm bg-[linear-gradient(270deg,#3A3A3A,#A7A3A0)]" />

      {/* Metallic rim */}
      <div className="rounded-[52px] bg-[linear-gradient(145deg,#E5E2DE_0%,#3A3A3A_22%,#A7A3A0_48%,#0E0E0E_72%,#A7A3A0_100%)] p-[1.5px] shadow-[0_70px_90px_-40px_rgba(0,0,0,0.85),0_30px_40px_-30px_rgba(0,0,0,0.6)]">
        <div className="rounded-[50.5px] bg-preto p-[11px]">
          <div className="relative aspect-[390/844] overflow-hidden rounded-[40px] bg-preto">
            <div className="phone-scroll will-change-transform" style={{ ["--scroll-end" as string]: scrollEnd }}>
              <Image
                src="/projects/nexora-mobile.webp"
                alt={alt}
                width={shot.width}
                height={shot.height}
                unoptimized // already an optimized webp; keeps the tall capture intact
                className="block h-auto w-full"
              />
            </div>
            {/* Dynamic island */}
            <span aria-hidden="true" className="absolute top-[1.6%] left-1/2 h-[3.6%] w-[31%] -translate-x-1/2 rounded-full bg-preto" />
            {/* Glass reflection */}
            <span aria-hidden="true" className="pointer-events-none absolute inset-0 bg-[linear-gradient(115deg,rgba(248,246,243,0.07)_0%,transparent_35%)]" />
          </div>
        </div>
      </div>
    </div>
  );
}
