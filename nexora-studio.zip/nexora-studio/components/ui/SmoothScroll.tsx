"use client";

import { useEffect } from "react";
import {
  ScrollTrigger,
  destroyLenis,
  initLenis,
  prefersReducedMotion,
  scrollToId,
} from "@/lib/gsap";

/**
 * Boots Lenis (unless reduced motion), refreshes ScrollTrigger once fonts are
 * ready, and restores the #section from the URL after the hero pin exists.
 */
export function SmoothScroll() {
  useEffect(() => {
    if ("scrollRestoration" in history) history.scrollRestoration = "manual";
    if (!prefersReducedMotion()) initLenis();

    let cancelled = false;
    document.fonts.ready.then(() => {
      if (cancelled) return;
      ScrollTrigger.refresh();
      const hash = window.location.hash.slice(1);
      if (hash) requestAnimationFrame(() => scrollToId(hash, true));
    });

    return () => {
      cancelled = true;
      destroyLenis();
    };
  }, []);

  return null;
}
