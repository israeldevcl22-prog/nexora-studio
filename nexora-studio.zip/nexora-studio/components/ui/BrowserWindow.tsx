import Image from "next/image";

type Props = {
  src: string;
  alt: string;
  /** Domain shown in the address bar. */
  url: string;
  className?: string;
  sizes?: string;
};

/**
 * Monochrome browser window (dark title bar, grey dots, address pill) with a
 * real screenshot inside and a faint metallic highlight on its top edge.
 */
export function BrowserWindow({ src, alt, url, className = "", sizes = "(min-width: 1024px) 40vw, 80vw" }: Props) {
  return (
    <div
      className={`relative overflow-hidden rounded-[12px] border border-white/[0.08] bg-[#1A1A1A] shadow-[0_50px_80px_-30px_rgba(0,0,0,0.85),0_18px_30px_-18px_rgba(0,0,0,0.6)] ${className}`}
    >
      {/* Metallic top edge */}
      <span
        aria-hidden="true"
        className="absolute inset-x-0 top-0 z-10 h-px bg-[linear-gradient(90deg,transparent_5%,#A7A3A0_35%,#F8F6F3_50%,#A7A3A0_65%,transparent_95%)] opacity-50"
      />

      {/* Title bar */}
      <div className="flex h-7 items-center gap-3 px-3 md:h-8">
        <div className="flex gap-1.5" aria-hidden="true">
          <span className="size-2 rounded-full bg-[#3A3A3A]" />
          <span className="size-2 rounded-full bg-[#3A3A3A]" />
          <span className="size-2 rounded-full bg-[#3A3A3A]" />
        </div>
        <div className="mx-auto flex h-[18px] w-[58%] items-center justify-center truncate rounded-full bg-white/[0.05] px-3 text-[9px] tracking-wide text-cinza-medio md:h-5 md:text-[10px]">
          {url}
        </div>
        <span className="w-[42px]" aria-hidden="true" />
      </div>

      {/* Page */}
      <div className="relative aspect-[16/10] bg-preto">
        <Image src={src} alt={alt} fill sizes={sizes} className="object-cover object-top" />
      </div>
    </div>
  );
}
