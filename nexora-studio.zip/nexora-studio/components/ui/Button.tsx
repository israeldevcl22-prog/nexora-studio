import type { AnchorHTMLAttributes, ReactNode } from "react";
import { ArrowRight } from "lucide-react";

type Variant = "light" | "dark" | "ghost-light" | "ghost-dark";
type Size = "sm" | "md" | "lg";

type Props = AnchorHTMLAttributes<HTMLAnchorElement> & {
  variant?: Variant;
  size?: Size;
  arrow?: boolean;
  icon?: ReactNode;
};

const variants: Record<Variant, string> = {
  // off-white pill for dark backgrounds
  light:
    "bg-off-white text-preto hover:bg-cinza-claro focus-visible:outline-off-white",
  // black pill for light backgrounds
  dark: "bg-preto text-off-white hover:bg-cinza-escuro focus-visible:outline-preto",
  "ghost-light":
    "border border-off-white/30 text-off-white hover:border-off-white focus-visible:outline-off-white",
  "ghost-dark":
    "border border-preto/20 text-preto hover:border-preto focus-visible:outline-preto",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-4 text-[13px] gap-2",
  md: "h-11 px-5 text-sm gap-2.5",
  lg: "h-14 px-7 text-[15px] gap-3",
};

/** Pill button rendered as a link. Arrow nudges right on hover. */
export function Button({
  variant = "dark",
  size = "md",
  arrow = true,
  icon,
  className = "",
  children,
  ...rest
}: Props) {
  return (
    <a
      className={`group inline-flex shrink-0 items-center justify-center rounded-full font-medium tracking-[-0.005em] whitespace-nowrap transition-colors duration-300 focus-visible:outline-2 focus-visible:outline-offset-4 ${variants[variant]} ${sizes[size]} ${className}`}
      {...rest}
    >
      {icon}
      <span>{children}</span>
      {arrow && (
        <ArrowRight
          aria-hidden="true"
          strokeWidth={1.5}
          className="size-4 transition-transform duration-300 ease-out group-hover:translate-x-1"
        />
      )}
    </a>
  );
}
