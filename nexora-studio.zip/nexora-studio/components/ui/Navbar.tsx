"use client";

import { useEffect, useRef, useState } from "react";
import { useTranslations } from "next-intl";
import { BrandLogo } from "@/components/brand/BrandLogo";
import { ScrollTrigger, getLenis, scrollToId } from "@/lib/gsap";
import { useHeroState } from "@/lib/heroStore";
import { LocaleSwitcher } from "./LocaleSwitcher";
import { WhatsAppButton } from "./WhatsAppButton";

const LINKS = [
  { id: "servicos", key: "services" },
  { id: "projetos", key: "projects" },
  { id: "sobre", key: "about" },
  { id: "contato", key: "contact" },
] as const;

type Theme = "light" | "dark";

export function Navbar() {
  const t = useTranslations("nav");
  const hero = useHeroState();
  const [sectionTheme, setSectionTheme] = useState<Theme>("light");
  const [open, setOpen] = useState(false);
  const menuButton = useRef<HTMLButtonElement>(null);
  const firstLink = useRef<HTMLAnchorElement>(null);

  // Track which section sits under the bar to adapt colors + remember position.
  useEffect(() => {
    const sections = gsapSections();
    const triggers = sections.map((el) => {
      const apply = () => {
        setSectionTheme((el.dataset.navTheme as Theme) ?? "light");
        document.documentElement.dataset.section = el.id;
      };
      // onEnter/onEnterBack also fire when a jump skips over the section.
      return ScrollTrigger.create({
        trigger: el,
        start: "top top+=36",
        end: "bottom top+=36",
        refreshPriority: -1,
        onEnter: apply,
        onEnterBack: apply,
        onRefresh: (self) => self.isActive && apply(),
      });
    });
    return () => triggers.forEach((tr) => tr.kill());
  }, []);

  // Mobile menu: lock scroll, focus management, Esc to close.
  useEffect(() => {
    if (!open) return;
    const lenis = getLenis();
    const opener = menuButton.current;
    lenis?.stop();
    document.body.style.overflow = "hidden";
    firstLink.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      lenis?.start();
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
      opener?.focus();
    };
  }, [open]);

  const theme: Theme = hero.past ? sectionTheme : "light";
  const onDark = theme === "dark";
  const full = hero.complete;

  const go = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setOpen(false);
    // Let the menu unlock scrolling first.
    requestAnimationFrame(() => scrollToId(id));
  };

  const reveal = `transition-[opacity,visibility] duration-700 ease-out ${
    full ? "visible opacity-100" : "invisible opacity-0"
  }`;

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,color,opacity,visibility] duration-500 ${
          hero.navHidden ? "invisible opacity-0" : "visible opacity-100"
        } ${
          hero.past
            ? onDark
              ? "border-b border-cinza-escuro/70 bg-preto/75 backdrop-blur-md"
              : "border-b border-cinza-claro bg-off-white/80 backdrop-blur-md"
            : "border-b border-transparent bg-transparent"
        } ${onDark ? "text-off-white" : "text-preto"}`}
      >
        <div className="mx-auto flex h-[72px] max-w-[1320px] items-center justify-between px-5 md:px-10">
          <a
            href="#top"
            onClick={go("top")}
            aria-label={t("home")}
            className="rounded-sm focus-visible:outline-1 focus-visible:outline-offset-4 focus-visible:outline-current"
          >
            <NavLogo onDark={onDark} />
          </a>

          <nav aria-label={t("primary")} className={`hidden md:block ${reveal}`}>
            <ul className="flex items-center gap-9 text-[14px] font-medium">
              {LINKS.map((l) => (
                <li key={l.id}>
                  <a
                    href={`#${l.id}`}
                    onClick={go(l.id)}
                    className="relative rounded-sm py-1 opacity-80 transition-opacity duration-300 after:absolute after:inset-x-0 after:-bottom-0.5 after:h-px after:origin-left after:scale-x-0 after:bg-current after:transition-transform after:duration-300 hover:opacity-100 hover:after:scale-x-100 focus-visible:outline-1 focus-visible:outline-offset-4 focus-visible:outline-current"
                  >
                    {t(l.key)}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className={`flex items-center gap-5 ${reveal}`}>
            <LocaleSwitcher tone={onDark ? "light" : "dark"} className="hidden md:flex" />
            <WhatsAppButton
              size="sm"
              variant={onDark ? "light" : "dark"}
              arrow={false}
              className="hidden md:inline-flex"
            >
              {t("cta")}
            </WhatsAppButton>
            <button
              ref={menuButton}
              type="button"
              onClick={() => setOpen(true)}
              aria-label={t("openMenu")}
              aria-expanded={open}
              aria-controls="mobile-menu"
              className="-mr-2 flex size-11 flex-col items-center justify-center gap-[7px] rounded-full focus-visible:outline-1 focus-visible:outline-current md:hidden"
            >
              <span className="block h-px w-6 bg-current" />
              <span className="block h-px w-6 bg-current" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile full-screen menu */}
      <div
        id="mobile-menu"
        role="dialog"
        aria-modal="true"
        aria-label={t("primary")}
        className={`fixed inset-0 z-[60] flex flex-col bg-preto text-off-white transition-[opacity,visibility] duration-500 md:hidden ${
          open ? "visible opacity-100" : "invisible opacity-0"
        }`}
      >
        <div className="flex h-[72px] items-center justify-between px-5">
          <BrandLogo kind="icon" tone="light" alt="Nexora Studio" sizes="40px" className="h-9 w-auto" />
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label={t("closeMenu")}
            className="-mr-2 relative flex size-11 items-center justify-center rounded-full focus-visible:outline-1 focus-visible:outline-off-white"
          >
            <span className="absolute block h-px w-6 rotate-45 bg-current" />
            <span className="absolute block h-px w-6 -rotate-45 bg-current" />
          </button>
        </div>
        <nav className="flex flex-1 flex-col justify-center px-5">
          <ul className="space-y-3">
            {LINKS.map((l, i) => (
              <li
                key={l.id}
                className="transition-[opacity,transform] duration-700 ease-out"
                style={{
                  transitionDelay: open ? `${120 + i * 60}ms` : "0ms",
                  opacity: open ? 1 : 0,
                  transform: open ? "none" : "translateY(16px)",
                }}
              >
                <a
                  ref={i === 0 ? firstLink : undefined}
                  href={`#${l.id}`}
                  onClick={go(l.id)}
                  tabIndex={open ? 0 : -1}
                  className="block py-1 text-[44px] font-medium leading-tight tracking-[-0.03em] focus-visible:outline-1 focus-visible:outline-off-white"
                >
                  {t(l.key)}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <div className="flex items-center justify-between border-t border-cinza-escuro px-5 py-6">
          <LocaleSwitcher tone="light" />
          <WhatsAppButton size="sm" variant="light" tabIndex={open ? 0 : -1}>
            {t("cta")}
          </WhatsAppButton>
        </div>
      </div>
    </>
  );
}

/** Both official variants stacked; the right one fades in for the background. */
function NavLogo({ onDark }: { onDark: boolean }) {
  return (
    <>
      {/* Mobile: the app icon only */}
      <span className="relative block md:hidden">
        <BrandLogo kind="icon" tone="dark" alt="Nexora Studio" priority sizes="40px" className={`h-9 w-auto transition-opacity duration-500 ${onDark ? "opacity-0" : "opacity-100"}`} />
        <BrandLogo kind="icon" tone="light" alt="" sizes="40px" className={`absolute inset-0 h-9 w-auto transition-opacity duration-500 ${onDark ? "opacity-100" : "opacity-0"}`} />
      </span>
      {/* Desktop: the full wordmark */}
      <span className="relative hidden md:block">
        <BrandLogo kind="wordmark" tone="dark" alt="Nexora Studio" priority sizes="160px" className={`h-[34px] w-auto transition-opacity duration-500 ${onDark ? "opacity-0" : "opacity-100"}`} />
        <BrandLogo kind="wordmark" tone="light" alt="" sizes="160px" className={`absolute inset-0 h-[34px] w-auto transition-opacity duration-500 ${onDark ? "opacity-100" : "opacity-0"}`} />
      </span>
    </>
  );
}

function gsapSections() {
  return Array.from(document.querySelectorAll<HTMLElement>("[data-nav-theme]"));
}
