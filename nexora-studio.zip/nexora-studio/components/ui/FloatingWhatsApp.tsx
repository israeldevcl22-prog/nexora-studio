"use client";

import { useEffect, useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import { whatsappLink } from "@/lib/whatsapp";
import { useHeroState } from "@/lib/heroStore";
import { WhatsAppIcon } from "./icons";

/** Appears once the hero is done; hides while the final CTA is on screen. */
export function FloatingWhatsApp() {
  const locale = useLocale();
  const t = useTranslations("whatsapp");
  const { past } = useHeroState();
  const [ctaVisible, setCtaVisible] = useState(false);

  useEffect(() => {
    const targets = ["contato", "rodape"]
      .map((id) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];
    const seen = new Set<Element>();
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => (e.isIntersecting ? seen.add(e.target) : seen.delete(e.target)));
        setCtaVisible(seen.size > 0);
      },
      { threshold: 0.2 }
    );
    targets.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  const show = past && !ctaVisible;

  return (
    <a
      href={whatsappLink(locale)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={t("floating")}
      tabIndex={show ? 0 : -1}
      aria-hidden={show ? undefined : true}
      className={`fixed right-5 bottom-5 z-40 flex size-12 items-center justify-center rounded-full border border-off-white/70 bg-preto text-off-white shadow-[0_10px_30px_-10px_rgba(14,14,14,0.6)] transition-[opacity,transform,visibility,border-color] duration-500 ease-out hover:border-off-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-preto md:right-8 md:bottom-8 ${
        show ? "visible translate-y-0 opacity-100" : "invisible translate-y-4 opacity-0"
      }`}
    >
      <WhatsAppIcon className="size-[22px]" />
    </a>
  );
}
