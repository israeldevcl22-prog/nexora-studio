"use client";

import type { AnchorHTMLAttributes } from "react";
import { scrollToId } from "@/lib/gsap";

/** In-page anchor that scrolls with Lenis (falls back to the native jump without JS). */
export function ScrollLink({ to, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { to: string }) {
  return (
    <a
      href={`#${to}`}
      onClick={(e) => {
        e.preventDefault();
        scrollToId(to);
      }}
      {...rest}
    />
  );
}
