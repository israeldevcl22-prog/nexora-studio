import { useLocale, useTranslations } from "next-intl";
import type { ComponentProps } from "react";
import { whatsappLink } from "@/lib/whatsapp";
import { Button } from "./Button";

type Props = Omit<ComponentProps<typeof Button>, "href"> & {
  /** Optional project name to mention in the pre-filled message. */
  context?: string;
};

export function WhatsAppButton({ context, children, ...rest }: Props) {
  const locale = useLocale();
  const t = useTranslations("whatsapp");
  return (
    <Button
      href={whatsappLink(locale, context)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={
        typeof children === "string" ? `${children} (${t("suffix")})` : t("aria")
      }
      {...rest}
    >
      {children}
    </Button>
  );
}
