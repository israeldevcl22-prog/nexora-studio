"use client";

import { useRef } from "react";
import { useTranslations } from "next-intl";
import { ArrowRight } from "lucide-react";
import { BrowserWindow } from "./BrowserWindow";
import { gsap, ScrollTrigger, scrollToId, useGSAP } from "@/lib/gsap";

type Layer = {
  key: "back" | "mid" | "front";
  src: string;
  url: string;
  name: string;
  /** Element to scroll to on click (showcase card). */
  target: string;
  /** Depth in px. */
  z: number;
  /** Parallax travel in px while the section scrolls by. */
  travel: number;
  /** Position/size classes (desktop + mobile). */
  className: string;
  windowClass?: string;
  sizes: string;
};

const LAYERS: Layer[] = [
  {
    key: "back",
    src: "/projects/nexora-desktop.webp",
    url: "", // filled from SITE_DOMAIN (server) via the `domain` prop
    name: "Nexora Studio",
    target: "projetos",
    z: -160,
    travel: -15,
    className: "hidden lg:block left-[40%] top-0 w-[56%]",
    windowClass: "[filter:blur(1px)_brightness(0.6)]",
    sizes: "(min-width: 1024px) 34vw, 1px",
  },
  {
    key: "mid",
    src: "/projects/la-sanduicheria-desktop.webp",
    url: "la-sanduicheria-site.vercel.app",
    name: "LA Sanduicheria",
    target: "projeto-la-sanduicheria",
    z: 0,
    travel: -40,
    className: "left-[24%] top-0 w-[74%] lg:left-[25%] lg:top-[17%] lg:w-[62%]",
    sizes: "(min-width: 1024px) 38vw, 70vw",
  },
  {
    key: "front",
    src: "/projects/liga-forte-desktop.webp",
    url: "liga-forte.vercel.app",
    name: "Liga Forte",
    target: "projeto-liga-forte",
    z: 120,
    travel: -80,
    className: "left-0 top-[34%] w-[78%] lg:top-[40%] lg:w-[66%]",
    sizes: "(min-width: 1024px) 42vw, 75vw",
  },
];

/**
 * Three browser windows in CSS 3D (perspective 1800px), at different depths.
 * Nesting keeps every transform on its own element:
 *   stage (perspective) > tilt (mouse) > group (scroll rotation/scale)
 *   > layer (depth + parallax) > enter (entrance) > link (hover push) > window
 */
export function ValueWindows({ domain }: { domain: string }) {
  const t = useTranslations("valueProposition");
  const root = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const stage = root.current!;
      const section = stage.closest("section") ?? stage;
      const q = gsap.utils.selector(stage);
      const group = q("[data-group]")[0];
      const tilt = q("[data-tilt]")[0];
      const layers = q("[data-layer]");
      const enters = q("[data-enter]");
      const mm = gsap.matchMedia();

      mm.add(
        {
          desktop: "(min-width: 1024px) and (prefers-reduced-motion: no-preference)",
          mobile: "(max-width: 1023.98px) and (prefers-reduced-motion: no-preference)",
          fine: "(min-width: 1024px) and (pointer: fine) and (prefers-reduced-motion: no-preference)",
        },
        (ctx) => {
          const { desktop, mobile, fine } = ctx.conditions as Record<string, boolean>;
          if (!desktop && !mobile) return;

          const baseY = desktop ? -18 : -8;
          const baseX = desktop ? 6 : 4;
          gsap.set(group, { rotationY: baseY, rotationX: baseX, transformStyle: "preserve-3d" });
          layers.forEach((el, i) => gsap.set(el, { z: LAYERS[i].z }));

          // Entrance: back → mid → front.
          gsap.set(enters, { y: 60, autoAlpha: 0 });
          ScrollTrigger.create({
            trigger: stage,
            start: "top 82%",
            once: true,
            refreshPriority: -1,
            onEnter: () =>
              gsap.to(enters, { y: 0, autoAlpha: 1, duration: 1.1, stagger: 0.15, ease: "power3.out" }),
          });

          // Depth parallax while the section passes, then a gentle exit upward.
          const tl = gsap.timeline({
            defaults: { ease: "none" },
            scrollTrigger: {
              trigger: section,
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
              refreshPriority: -1,
              onToggle: (self) => gsap.set(layers, { willChange: self.isActive ? "transform" : "auto" }),
            },
          });
          layers.forEach((el, i) => tl.fromTo(el, { y: 0 }, { y: LAYERS[i].travel, duration: 1 }, 0));
          tl.fromTo(group, { rotationY: baseY }, { rotationY: desktop ? -10 : -5, duration: 0.6, ease: "power1.out" }, 0)
            .fromTo(group, { y: 0, scale: 1 }, { y: -60, scale: 1.05, duration: 0.35, ease: "power1.in" }, 0.65);

          // Mouse: at most ±3°, smoothed.
          if (fine) {
            const rotY = gsap.quickTo(tilt, "rotationY", { duration: 0.9, ease: "power3.out" });
            const rotX = gsap.quickTo(tilt, "rotationX", { duration: 0.9, ease: "power3.out" });
            const onMove = (e: Event) => {
              const m = e as MouseEvent;
              rotY(((m.clientX / window.innerWidth) * 2 - 1) * 3);
              rotX(-((m.clientY / window.innerHeight) * 2 - 1) * 3);
            };
            const onLeave = () => {
              rotY(0);
              rotX(0);
            };
            section.addEventListener("mousemove", onMove);
            section.addEventListener("mouseleave", onLeave);
            return () => {
              section.removeEventListener("mousemove", onMove);
              section.removeEventListener("mouseleave", onLeave);
            };
          }
        }
      );

      return () => mm.revert();
    },
    { scope: root }
  );

  return (
    <div ref={root} className="relative h-[300px] w-full [perspective:1800px] sm:h-[420px] lg:h-[620px] lg:w-[118%]">
      <div data-tilt className="absolute inset-0 [transform-style:preserve-3d]">
        <div
          data-group
          className="absolute inset-0 [transform-style:preserve-3d] [transform:rotateY(-8deg)_rotateX(4deg)] lg:[transform:rotateY(-18deg)_rotateX(6deg)]"
        >
          {LAYERS.map((l) => (
            <div
              key={l.key}
              data-layer
              className={`absolute [transform-style:preserve-3d] ${l.className}`}
              style={{ transform: `translateZ(${l.z}px)` }}
            >
              <div data-enter className="[transform-style:preserve-3d]">
                <a
                  href={`#${l.target}`}
                  aria-label={t("viewProjectAria", { name: l.name })}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToId(l.target);
                  }}
                  className="group relative block rounded-[12px] transition-transform duration-500 ease-out [transform-style:preserve-3d] hover:[transform:translateZ(20px)] focus-visible:[transform:translateZ(20px)] focus-visible:outline-1 focus-visible:outline-offset-4 focus-visible:outline-off-white"
                >
                  <div aria-hidden="true">
                    <BrowserWindow src={l.src} alt="" url={l.key === "back" ? domain : l.url} sizes={l.sizes} className={l.windowClass} />
                  </div>
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute right-4 bottom-4 inline-flex items-center gap-1.5 rounded-full bg-off-white px-3.5 py-2 text-[12px] font-medium text-preto opacity-0 shadow-[0_8px_24px_-8px_rgba(0,0,0,0.6)] transition-[opacity,transform] duration-300 group-hover:translate-y-0 group-hover:opacity-100 group-focus-visible:opacity-100 translate-y-1"
                  >
                    {t("viewProject")}
                    <ArrowRight strokeWidth={1.5} className="size-3.5" />
                  </span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
