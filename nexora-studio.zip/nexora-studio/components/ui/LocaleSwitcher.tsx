"use client";

import { useLocale, useTranslations } from "next-intl";
import { routing } from "@/i18n/routing";

/** Current section id, kept up to date by the Navbar so switching keeps position. */
function currentHash() {
  if (typeof document === "undefined") return "";
  const id = document.documentElement.dataset.section;
  return id && id !== "top" ? `#${id}` : "";
}

export function LocaleSwitcher({
  tone = "dark",
  className = "",
}: {
  tone?: "dark" | "light";
  className?: string;
}) {
  const locale = useLocale();
  const t = useTranslations("nav");

  const base = tone === "dark" ? "text-preto" : "text-off-white";

  return (
    <nav aria-label={t("language")} className={`flex items-center gap-1.5 text-[12px] font-medium tracking-[0.2em] ${base} ${className}`}>
      {routing.locales.map((l, i) => {
        const active = l === locale;
        const href = l === routing.defaultLocale ? "/" : `/${l}`;
        return (
          <span key={l} className="flex items-center gap-1.5">
            {i > 0 && <span aria-hidden="true" className="opacity-40">|</span>}
            <a
              href={href}
              hrefLang={l === "pt" ? "pt-BR" : l}
              lang={l === "pt" ? "pt-BR" : l}
              aria-current={active ? "true" : undefined}
              onClick={(e) => {
                if (active) {
                  e.preventDefault();
                  return;
                }
                e.preventDefault();
                window.location.href = href + currentHash();
              }}
              className={`rounded px-0.5 uppercase transition-opacity duration-300 focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-current ${
                active ? "opacity-100" : "opacity-50 hover:opacity-100"
              }`}
            >
              {l}
            </a>
          </span>
        );
      })}
    </nav>
  );
}
