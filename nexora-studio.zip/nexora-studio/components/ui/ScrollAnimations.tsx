"use client";

import { gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";

/**
 * Restrained scroll motion for everything below the hero:
 * fade-up reveals, mockup parallax and the process line.
 * Driven by data attributes so sections stay Server Components.
 */
export function ScrollAnimations() {
  useGSAP(() => {
    const mm = gsap.matchMedia();

    mm.add("(prefers-reduced-motion: no-preference)", () => {
      const reveals = gsap.utils.toArray<HTMLElement>("[data-reveal]");
      gsap.set(reveals, { autoAlpha: 0, y: 24 });
      const show = (batch: Element[]) =>
        gsap.to(batch, {
          autoAlpha: 1,
          y: 0,
          duration: 0.8,
          ease: "power3.out",
          stagger: 0.08,
          overwrite: true,
        });
      ScrollTrigger.batch(reveals, {
        start: "top 88%",
        once: true,
        onEnter: show,
        // Landing mid-page (e.g. #sobre) must not leave content hidden above.
        onLeave: show,
      });

      gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((el) => {
        gsap.fromTo(
          el,
          { y: 40 },
          {
            y: -40,
            ease: "none",
            scrollTrigger: {
              trigger: el.parentElement,
              start: "top bottom",
              end: "bottom top",
              scrub: true,
              refreshPriority: -1,
            },
          }
        );
      });

      // Headlines split into [data-word]: mask reveal word by word.
      gsap.utils.toArray<HTMLElement>("h2:has([data-word]), h1:has([data-word])").forEach((title) => {
        const words = title.querySelectorAll("[data-word]");
        gsap.set(words, { yPercent: 110 });
        ScrollTrigger.create({
          trigger: title,
          start: "top 85%",
          once: true,
          onEnter: () => gsap.to(words, { yPercent: 0, duration: 0.9, stagger: 0.06, ease: "power3.out" }),
          onLeave: () => gsap.set(words, { yPercent: 0 }),
        });
      });

      // N watermarks drift very slowly.
      gsap.utils.toArray<HTMLElement>("[data-parallax-slow]").forEach((el) => {
        gsap.fromTo(
          el,
          { y: 80 },
          {
            y: -80,
            ease: "none",
            scrollTrigger: {
              trigger: el.closest("section") ?? el,
              start: "top bottom",
              end: "bottom top",
              scrub: true,
              refreshPriority: -1,
            },
          }
        );
      });

      const process = document.querySelector<HTMLElement>("[data-process]");
      if (process) {
        const h = process.querySelector<HTMLElement>("[data-draw-h]")!;
        const v = process.querySelector<HTMLElement>("[data-draw-v]")!;
        const dots = Array.from(process.querySelectorAll<HTMLElement>("[data-dot]"));
        gsap.set(h, { scaleX: 0 });
        gsap.set(v, { scaleY: 0 });

        // Each dot fills once the line has reached it.
        const syncDots = (progress: number) => {
          const horizontal = getComputedStyle(h).display !== "none";
          // Lines span the whole [data-process] box; measure that (unscaled).
          const line = process.getBoundingClientRect();
          dots.forEach((dot) => {
            const r = dot.getBoundingClientRect();
            const at = horizontal
              ? (r.left + r.width / 2 - line.left) / line.width
              : (r.top + r.height / 2 - line.top) / line.height;
            dot.dataset.active = String(progress >= at - 0.001);
          });
        };

        gsap.to([h, v], {
          scaleX: 1,
          scaleY: 1,
          ease: "none",
          scrollTrigger: {
            trigger: process,
            start: "top 75%",
            end: "bottom 55%",
            scrub: 0.8,
            refreshPriority: -1,
          },
          onUpdate() {
            syncDots(this.progress());
          },
        });
      }
    });

    return () => mm.revert();
  });

  return null;
}
