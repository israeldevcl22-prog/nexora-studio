type IconProps = { className?: string; strokeWidth?: number };

/** Thin-line WhatsApp glyph (monochrome, inherits currentColor). */
export function WhatsAppIcon({ className, strokeWidth = 1.5 }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M3.5 20.5l1.3-4.1A8.5 8.5 0 1 1 8 19.4l-4.5 1.1z" />
      <path d="M9.2 8.4c.2-.5.5-.6.8-.6h.5c.2 0 .4 0 .5.4l.7 1.6c.1.3 0 .5-.1.7l-.5.6c-.1.2-.2.3 0 .6.4.7 1 1.4 1.7 1.9.5.4 1 .7 1.5.9.2.1.4.1.6-.1l.6-.8c.2-.2.4-.2.6-.1l1.6.8c.3.1.4.2.4.4 0 .4-.1 1-.5 1.4-.5.5-1.3.8-2 .7-1.3-.2-2.7-.9-3.9-1.9-1.2-1-2.2-2.3-2.6-3.6-.3-.9-.1-1.9.4-2.5z" />
    </svg>
  );
}

/** Thin-line Instagram glyph — kept for when the profile goes live. */
export function InstagramIcon({ className, strokeWidth = 1.5 }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.3" cy="6.7" r="0.6" fill="currentColor" stroke="none" />
    </svg>
  );
}
