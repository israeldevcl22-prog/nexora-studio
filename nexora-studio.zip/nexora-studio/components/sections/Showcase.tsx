import Image from "next/image";
import { useLocale, useTranslations } from "next-intl";
import { ArrowUpRight, ArrowRight } from "lucide-react";
import { projects, type Project } from "@/data/projects";
import { BrandLogo } from "@/components/brand/BrandLogo";
import { whatsappLink } from "@/lib/whatsapp";

type Lang = "pt" | "en";

export function Showcase() {
  const t = useTranslations("showcase");
  const locale = useLocale() as Lang;

  return (
    <section
      id="projetos"
      data-nav-theme="dark"
      aria-labelledby="showcase-title"
      className="bg-preto px-5 py-28 text-off-white md:px-10 md:py-40"
    >
      <div className="mx-auto max-w-[1320px]">
        <p data-reveal className="eyebrow text-cinza-medio">
          {t("eyebrow")}
        </p>
        <h2
          id="showcase-title"
          data-reveal
          className="mt-8 max-w-[16ch] text-[34px] leading-[1.08] font-medium tracking-[-0.03em] text-balance md:text-[56px]"
        >
          {t("title")}
        </h2>

        <ul className="mt-16 grid gap-6 md:mt-24 md:grid-cols-2 md:gap-8">
          {projects.map((p) => (
            <li key={p.id} id={`projeto-${p.id}`} data-reveal className="scroll-mt-24">
              <ProjectCard project={p} locale={locale} />
            </li>
          ))}
        </ul>

        <p data-reveal className="mt-20 flex flex-col items-start gap-4 text-[17px] md:mt-24 md:flex-row md:items-center md:justify-center md:gap-6 md:text-lg">
          <span className="text-cinza-medio">{t("ctaLead")}</span>
          <a
            href={whatsappLink(locale)}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-2 rounded-sm border-b border-off-white/40 pb-1 font-medium transition-colors duration-300 hover:border-off-white focus-visible:outline-1 focus-visible:outline-offset-4 focus-visible:outline-off-white"
          >
            {t("ctaLink")}
            <ArrowRight aria-hidden="true" strokeWidth={1.5} className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
          </a>
        </p>
      </div>
    </section>
  );
}

function ProjectCard({ project: p, locale }: { project: Project; locale: Lang }) {
  const t = useTranslations("showcase");
  const name = p.name[locale];
  const live = p.status === "live";

  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-[20px] border border-cinza-escuro/80 bg-preto transition-colors duration-500 hover:border-cinza-medio/60">
      {/* Mockup stage */}
      <div className="relative flex aspect-[16/11] items-center justify-center overflow-hidden bg-[radial-gradient(120%_90%_at_50%_0%,#3A3A3A_0%,#0E0E0E_70%)]">
        <div data-parallax className="w-full will-change-transform">
          {p.device === "laptop" ? (
            <Laptop project={p} live={live} alt={t("screenshotAlt", { name })} soon={t("soon")} />
          ) : (
            <Phone project={p} live={live} alt={t("screenshotAlt", { name })} soon={t("soon")} />
          )}
        </div>
      </div>

      {/* Text */}
      <div className="flex flex-1 flex-col gap-3 border-t border-cinza-escuro/80 p-7 md:p-8">
        <p className="text-[11px] font-semibold tracking-[0.3em] text-cinza-medio uppercase">
          {p.sector[locale]}
        </p>
        <div className="flex items-start justify-between gap-6">
          <h3 className="text-[22px] font-semibold tracking-[-0.02em] md:text-[26px]">{name}</h3>
          {live ? (
            <a
              href={p.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={t("viewAria", { name })}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-off-white/25 px-4 py-2 text-[13px] font-medium transition-colors duration-300 hover:border-off-white hover:bg-off-white hover:text-preto focus-visible:outline-1 focus-visible:outline-offset-4 focus-visible:outline-off-white"
            >
              {t("view")}
              <ArrowUpRight aria-hidden="true" strokeWidth={1.5} className="size-4" />
            </a>
          ) : (
            <span className="shrink-0 rounded-full border border-cinza-escuro px-3 py-1.5 text-[10px] font-semibold tracking-[0.3em] text-cinza-medio uppercase">
              {t("soon")}
            </span>
          )}
        </div>
        {p.description && (
          <p className="max-w-[46ch] text-[15px] leading-relaxed text-cinza-medio">
            {p.description[locale]}
          </p>
        )}
      </div>
    </article>
  );
}

type MockupProps = { project: Project; live: boolean; alt: string; soon: string };

function PlaceholderScreen({ soon }: { soon: string }) {
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-4 bg-[linear-gradient(160deg,#3A3A3A_0%,#0E0E0E_80%)]">
      <BrandLogo kind="n" tone="light" alt="" sizes="64px" className="h-10 w-auto opacity-30 md:h-12" />
      <span aria-hidden="true" className="text-[9px] font-semibold tracking-[0.4em] text-cinza-medio uppercase">
        {soon}
      </span>
    </div>
  );
}

function Laptop({ project: p, live, alt, soon }: MockupProps) {
  return (
    <div className="mx-auto w-[82%] drop-shadow-[0_30px_40px_rgba(0,0,0,0.55)]">
      <div className="rounded-t-[14px] border border-cinza-escuro bg-preto p-[2.2%] pb-[2.6%]">
        <div className="relative aspect-[16/10] overflow-hidden rounded-[4px] bg-preto">
          {live && p.images ? (
            <Image
              src={p.images.desktop}
              alt={alt}
              fill
              sizes="(min-width: 1320px) 520px, (min-width: 768px) 40vw, 82vw"
              className="object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.03]"
            />
          ) : (
            <PlaceholderScreen soon={soon} />
          )}
        </div>
      </div>
      <div className="relative mx-[-7%] h-[10px] rounded-b-[10px] bg-[linear-gradient(180deg,#3A3A3A,#0E0E0E)] md:h-[12px]">
        <span className="absolute top-0 left-1/2 h-[4px] w-[16%] -translate-x-1/2 rounded-b-[6px] bg-preto" />
      </div>
    </div>
  );
}

function Phone({ project: p, live, alt, soon }: MockupProps) {
  return (
    <div className="mx-auto w-[24%] max-w-[180px] drop-shadow-[0_30px_40px_rgba(0,0,0,0.55)]">
      <div className="rounded-[30px] border border-cinza-escuro bg-preto p-[5%]">
        <div className="relative aspect-[390/844] overflow-hidden rounded-[22px] bg-preto">
          {live && p.images ? (
            <Image
              src={p.images.mobile}
              alt={alt}
              fill
              sizes="180px"
              className="object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.03]"
            />
          ) : (
            <PlaceholderScreen soon={soon} />
          )}
          <span className="absolute top-[2.5%] left-1/2 h-[3%] w-[30%] -translate-x-1/2 rounded-full bg-preto" />
        </div>
      </div>
    </div>
  );
}
