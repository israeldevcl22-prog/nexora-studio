import { useTranslations } from "next-intl";
import { BrandLogo } from "@/components/brand/BrandLogo";
import { PhoneMockup } from "@/components/ui/PhoneMockup";
import { WhatsAppButton } from "@/components/ui/WhatsAppButton";
import { WhatsAppIcon } from "@/components/ui/icons";

export function FinalCta() {
  const t = useTranslations("finalCta");

  return (
    <section
      id="contato"
      data-nav-theme="light"
      aria-labelledby="cta-title"
      className="bg-off-white px-5 py-20 md:px-10 md:py-28"
    >
      <div className="relative mx-auto grid max-w-[1320px] overflow-hidden rounded-[24px] bg-preto text-off-white md:grid-cols-12">
        {/* Giant N at 4%, cut by the card edge */}
        <div aria-hidden="true" className="pointer-events-none absolute -right-[18%] -bottom-[30%] hidden md:block">
          <BrandLogo kind="n" tone="light" alt="" sizes="900px" className="h-[880px] w-auto opacity-[0.04]" />
        </div>

        <div className="relative z-10 flex flex-col justify-center p-8 pt-14 sm:p-12 md:col-span-7 md:p-16 lg:p-20">
          <div data-reveal>
            <BrandLogo kind="wordmark" tone="light" sizes="220px" className="h-auto w-[170px] md:w-[210px]" />
          </div>
          <h2
            id="cta-title"
            data-reveal
            className="mt-12 max-w-[14ch] text-[38px] leading-[1.04] font-medium tracking-[-0.03em] text-balance md:text-[60px]"
          >
            {t("title")}
          </h2>
          <p data-reveal className="mt-6 max-w-[42ch] text-[16px] leading-relaxed text-cinza-medio md:text-[18px]">
            {t("subtitle")}
          </p>
          <div data-reveal className="mt-10 flex flex-col items-start gap-4">
            <WhatsAppButton variant="light" size="lg" icon={<WhatsAppIcon className="size-5" />}>
              {t("button")}
            </WhatsAppButton>
            <p className="pl-2 text-[13px] text-cinza-medio">{t("note")}</p>
          </div>
        </div>

        {/* Phone with the site itself */}
        <div className="relative flex items-center justify-center overflow-hidden px-8 pt-4 pb-16 md:col-span-5 md:min-h-[640px] md:px-0 md:py-16">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute top-1/2 left-1/2 size-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(229,226,222,0.10)_0%,rgba(229,226,222,0.04)_40%,transparent_70%)]"
          />
          <div data-parallax className="relative w-[220px] will-change-transform md:w-[270px] lg:w-[290px]">
            <div className="md:[transform:perspective(1600px)_rotateY(-10deg)_rotateX(4deg)_rotateZ(-6deg)]">
              <PhoneMockup alt={t("phoneAlt")} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
