import { useLocale, useTranslations } from "next-intl";
import { ArrowRight } from "lucide-react";
import { SectionDecor } from "@/components/brand/SectionDecor";
import { ScrollLink } from "@/components/ui/ScrollLink";
import { ValueWindows } from "@/components/ui/ValueWindows";
import { SITE_DOMAIN } from "@/lib/site";
import { whatsappLink } from "@/lib/whatsapp";

/** Words wrapped for a mask reveal (animated by ScrollAnimations via [data-word]). */
function Words({ text, className }: { text: string; className?: string }) {
  return (
    <>
      {text.split(" ").map((w, i) => (
        <span key={i}>
          <span className="inline-block overflow-hidden pb-[0.08em] align-bottom">
            <span data-word className={`inline-block ${className ?? ""}`}>
              {w}
            </span>
          </span>{" "}
        </span>
      ))}
    </>
  );
}

/**
 * Value proposition right after the hero: result-focused headline, short
 * description, the site's strongest CTA, and real sites in 3D browser windows.
 */
export function ValueProposition() {
  const t = useTranslations("valueProposition");
  const tw = useTranslations("whatsapp");
  const locale = useLocale();
  const trust = t.raw("trust") as string[];

  return (
    <section
      id="proposta"
      data-nav-theme="dark"
      aria-labelledby="vp-title"
      className="relative overflow-hidden bg-preto px-5 py-28 text-off-white md:px-10 lg:flex lg:min-h-screen lg:items-center lg:py-32"
    >
      <SectionDecor index={2} tone="dark" watermark="left" />

      <div className="relative z-10 mx-auto grid w-full max-w-[1320px] items-center gap-16 lg:grid-cols-[45fr_55fr] lg:gap-10">
        <div>
          <p data-reveal className="eyebrow text-cinza-medio">
            {t("eyebrow")}
          </p>

          <h2
            id="vp-title"
            className="mt-8 text-[38px] leading-[1.04] font-medium tracking-[-0.03em] sm:text-[48px] lg:text-[60px] xl:text-[68px]"
          >
            <Words text={t("headlineLead")} className="text-cinza-medio" />
            <Words text={t("headlineEmphasis")} className="text-off-white" />
          </h2>

          <p data-reveal className="mt-8 max-w-[520px] text-[16px] leading-relaxed text-cinza-medio md:text-[18px]">
            {t("description")}
          </p>

          <div data-reveal className="mt-11 flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:gap-8">
            <a
              href={whatsappLink(locale)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${t("cta")} (${tw("suffix")})`}
              className="group relative inline-flex h-[60px] shrink-0 items-center gap-3 overflow-hidden rounded-full bg-off-white px-8 text-[16px] font-medium tracking-[-0.01em] text-preto transition-shadow duration-500 hover:shadow-[0_0_0_1px_rgba(167,163,160,0.5),0_18px_40px_-18px_rgba(248,246,243,0.35)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-off-white md:h-16 md:px-9"
            >
              {/* Metallic sheen passing on hover */}
              <span
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 -translate-x-full bg-[linear-gradient(105deg,transparent_30%,rgba(167,163,160,0.35)_44%,rgba(255,255,255,0.95)_50%,rgba(167,163,160,0.35)_56%,transparent_70%)] transition-transform duration-[900ms] ease-out group-hover:translate-x-full"
              />
              <span className="relative">{t("cta")}</span>
              <ArrowRight
                aria-hidden="true"
                strokeWidth={1.5}
                className="relative size-5 transition-transform duration-300 ease-out group-hover:translate-x-1.5"
              />
            </a>

            <ScrollLink
              to="projetos"
              className="rounded-sm border-b border-off-white/30 pb-1 text-[15px] font-medium text-off-white/90 transition-colors duration-300 hover:border-off-white hover:text-off-white focus-visible:outline-1 focus-visible:outline-offset-4 focus-visible:outline-off-white"
            >
              {t("secondary")}
            </ScrollLink>
          </div>

          <ul
            data-reveal
            className="mt-12 flex flex-wrap items-center gap-x-3 gap-y-2 text-[10.5px] font-medium tracking-[0.16em] text-cinza-medio uppercase xl:text-[11px]"
          >
            {trust.map((item, i) => (
              // Each item never breaks inside, and the "·" stays at the end of the
              // previous item, so a wrapped line never starts with a separator.
              <li key={item} className="flex items-center gap-3 whitespace-nowrap">
                {item}
                {i < trust.length - 1 && <span aria-hidden="true">·</span>}
              </li>
            ))}
          </ul>
        </div>

        <ValueWindows domain={SITE_DOMAIN} />
      </div>
    </section>
  );
}
