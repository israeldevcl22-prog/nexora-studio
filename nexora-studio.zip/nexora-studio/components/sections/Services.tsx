import { useTranslations } from "next-intl";
import { ChartNoAxesColumn, Layers, Megaphone, Monitor } from "lucide-react";
import { SectionDecor } from "@/components/brand/SectionDecor";

const ITEMS = [
  { key: "sites", Icon: Monitor },
  { key: "seo", Icon: ChartNoAxesColumn },
  { key: "marketing", Icon: Megaphone },
  { key: "custom", Icon: Layers },
] as const;

export function Services() {
  const t = useTranslations("services");

  return (
    <section
      id="servicos"
      data-nav-theme="light"
      aria-labelledby="services-title"
      className="relative overflow-hidden border-t border-cinza-claro bg-off-white px-5 py-28 md:px-10 md:py-40"
    >
      <SectionDecor index={4} light />
      <div className="relative z-10 mx-auto max-w-[1320px]">
        <p data-reveal className="eyebrow text-cinza-escuro">
          {t("eyebrow")}
        </p>
        <h2
          id="services-title"
          data-reveal
          className="mt-8 max-w-[18ch] text-[34px] leading-[1.08] font-medium tracking-[-0.03em] text-balance md:text-[56px]"
        >
          {t("title")}
        </h2>

        <ul className="mt-16 grid gap-4 sm:grid-cols-2 md:mt-24 lg:grid-cols-4 lg:gap-5">
          {ITEMS.map(({ key, Icon }) => (
            <li
              key={key}
              data-reveal
              className="group flex min-h-[260px] flex-col rounded-[18px] border border-cinza-claro bg-[#FBFAF8] p-7 shadow-[inset_0_1px_0_rgba(255,255,255,0.9),inset_0_0_24px_rgba(14,14,14,0.018),0_1px_2px_rgba(14,14,14,0.03)] transition-[transform,border-color,box-shadow] duration-500 ease-out hover:-translate-y-1.5 hover:border-cinza-medio hover:shadow-[inset_0_1px_0_rgba(255,255,255,0.9),0_24px_48px_-28px_rgba(14,14,14,0.25)] md:p-8"
            >
              <Icon
                aria-hidden="true"
                strokeWidth={1.5}
                className="size-7 text-preto transition-transform duration-500 ease-out group-hover:translate-x-1 group-hover:-translate-y-0.5"
              />
              <h3 className="mt-auto pt-14 text-[19px] font-semibold tracking-[-0.015em]">
                {t(`items.${key}.title`)}
              </h3>
              <p className="mt-3 text-[15px] leading-relaxed text-cinza-escuro">
                {t(`items.${key}.text`)}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
