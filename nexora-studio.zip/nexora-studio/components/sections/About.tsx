import fs from "node:fs";
import path from "node:path";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { BrandLogo } from "@/components/brand/BrandLogo";

// Drop a photo at public/brand/israel.jpg and it replaces the placeholder.
const hasPhoto = fs.existsSync(path.join(process.cwd(), "public/brand/israel.jpg"));

export function About() {
  const t = useTranslations("about");
  const highlights = [t("role"), t("school"), t("regions")];

  return (
    <section
      id="sobre"
      data-nav-theme="dark"
      aria-labelledby="about-title"
      className="bg-preto px-5 py-28 text-off-white md:px-10 md:py-40"
    >
      <div className="mx-auto grid max-w-[1320px] items-center gap-14 md:grid-cols-12 md:gap-10">
        <div data-reveal className="md:col-span-5">
          <div className="relative aspect-[4/5] overflow-hidden rounded-[20px] border border-cinza-escuro bg-cinza-escuro">
            {hasPhoto ? (
              <Image
                src="/brand/israel.jpg"
                alt={t("photoAlt")}
                fill
                sizes="(min-width: 768px) 40vw, 100vw"
                className="object-cover grayscale"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-[radial-gradient(90%_70%_at_50%_40%,#3A3A3A_0%,#0E0E0E_100%)]">
                <BrandLogo kind="n" tone="light" alt={t("photoPlaceholder")} sizes="160px" className="h-28 w-auto md:h-36" />
              </div>
            )}
          </div>
        </div>

        <div className="md:col-span-6 md:col-start-7">
          <p data-reveal className="eyebrow text-cinza-medio">
            {t("eyebrow")}
          </p>
          <h2
            id="about-title"
            data-reveal
            className="mt-8 text-[38px] leading-[1.05] font-medium tracking-[-0.03em] md:text-[60px]"
          >
            {t("title")}
          </h2>
          <div className="mt-10 space-y-5 text-[16px] leading-relaxed text-cinza-claro/85 md:text-[17px]">
            <p data-reveal>{t("p1")}</p>
            <p data-reveal>{t("p2")}</p>
            <p data-reveal>{t("p3")}</p>
          </div>
          <ul data-reveal className="mt-12 flex flex-wrap gap-x-6 gap-y-3 border-t border-cinza-escuro pt-8 text-[12px] font-medium tracking-[0.12em] text-cinza-medio uppercase">
            {highlights.map((h, i) => (
              <li key={h} className="flex items-center gap-6">
                {i > 0 && <span aria-hidden="true" className="hidden h-3 w-px bg-cinza-escuro sm:block" />}
                {h}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
