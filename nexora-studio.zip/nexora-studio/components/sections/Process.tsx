import { useTranslations } from "next-intl";
import { SectionDecor } from "@/components/brand/SectionDecor";

const STEPS = ["talk", "design", "build", "launch"] as const;

export function Process() {
  const t = useTranslations("process");

  return (
    <section
      id="processo"
      data-nav-theme="light"
      aria-labelledby="process-title"
      className="relative overflow-hidden border-t border-cinza-claro bg-off-white px-5 py-28 md:px-10 md:py-40"
    >
      <SectionDecor index={6} watermark="left" />
      <div className="relative z-10 mx-auto max-w-[1320px]">
        <p data-reveal className="eyebrow text-cinza-escuro">
          {t("eyebrow")}
        </p>
        <h2
          id="process-title"
          data-reveal
          className="mt-8 max-w-[18ch] text-[34px] leading-[1.08] font-medium tracking-[-0.03em] text-balance md:text-[56px]"
        >
          {t("title")}
        </h2>

        <div data-process className="relative mt-16 md:mt-28">
          {/* Track + line drawn on scroll (horizontal on desktop, vertical on mobile) */}
          <div aria-hidden="true" className="absolute top-0 bottom-0 left-[7px] w-px bg-cinza-claro md:top-[7px] md:right-0 md:bottom-auto md:left-0 md:h-px md:w-auto" />
          <div
            aria-hidden="true"
            data-draw-v
            className="absolute top-0 bottom-0 left-[7px] w-px origin-top bg-preto md:hidden"
          />
          <div
            aria-hidden="true"
            data-draw-h
            className="absolute top-[7px] right-0 left-0 hidden h-px origin-left bg-preto md:block"
          />

          <ol className="relative grid gap-14 md:grid-cols-4 md:gap-10">
            {STEPS.map((key, i) => (
              <li key={key} data-reveal className="relative pl-12 md:pt-14 md:pl-0">
                <span
                  aria-hidden="true"
                  data-dot
                  className="absolute top-0 left-0 block size-[15px] rounded-full border border-preto bg-off-white transition-colors duration-500 data-[active=true]:bg-preto"
                />
                <span className="text-[12px] font-semibold tracking-[0.3em] text-cinza-escuro tabular-nums">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-4 text-[22px] font-semibold tracking-[-0.02em]">
                  {t(`steps.${key}.title`)}
                </h3>
                <p className="mt-3 max-w-[30ch] text-[15px] leading-relaxed text-cinza-escuro">
                  {t(`steps.${key}.text`)}
                </p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
