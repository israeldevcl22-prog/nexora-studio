"use client";

import { useRef } from "react";
import { useTranslations } from "next-intl";
import { BrandLogo } from "@/components/brand/BrandLogo";
import { WindowLight } from "@/components/brand/WindowLight";
import { WhatsAppButton } from "@/components/ui/WhatsAppButton";
import { gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { setHeroState } from "@/lib/heroStore";

/**
 * Measured on public/brand/logo-n.png (alpha runs per row): the diagonal
 * stroke moves 12px right for every 12px down → 45°, and its chrome centre
 * sits at 49% / 50% of the image.
 */
const STROKE_ANGLE = 45;
const STROKE_CENTER = { x: 0.49, y: 0.5 };
/** Each metallic edge; the two together form the ~6px bar. */
const EDGE = 3;

/**
 * One metallic bar, born at the centre of the N's stroke:
 *   0–35%   grows to both sides along the stroke angle (container scaleX 0 → 1)
 *   35–65%  thickens until it covers the screen (halves' bodies scaleY, edges translateY)
 *   65–85%  splits along its axis; the halves slide apart and reveal the final state
 *   85–100% tagline, CTA and the full navbar
 * The big N never changes; it is swapped for the final state while the bar covers it.
 */
export function Hero() {
  const t = useTranslations("hero");
  const root = useRef<HTMLElement>(null);
  const spacer = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      ScrollTrigger.config({ ignoreMobileResize: true });
      const mm = gsap.matchMedia();

      mm.add(
        {
          desktop: "(min-width: 768px) and (prefers-reduced-motion: no-preference)",
          mobile: "(max-width: 767.98px) and (prefers-reduced-motion: no-preference)",
          reduce: "(prefers-reduced-motion: reduce)",
        },
        (ctx) => {
          const section = root.current!;
          const { desktop, reduce } = ctx.conditions as Record<string, boolean>;

          if (reduce) {
            // Final state is rendered by CSS; only report state to the navbar.
            setHeroState({ complete: true, navHidden: false });
            ScrollTrigger.create({
              trigger: section,
              start: "top top",
              end: "bottom top+=72",
              onLeave: () => setHeroState({ past: true }),
              onEnterBack: () => setHeroState({ past: false }),
            });
            return;
          }

          const q = gsap.utils.selector(section);
          const nImg = q("[data-n] img")[0] as HTMLElement;
          const nLayer = q("[data-nlayer]")[0];
          const final = q("[data-final]")[0];
          const axis = q("[data-axis]")[0] as HTMLElement;
          const bar = q("[data-bar]")[0] as HTMLElement;
          const halfTop = q("[data-half='top']")[0];
          const halfBottom = q("[data-half='bottom']")[0];
          const bodyTop = q("[data-half='top'] [data-body]")[0];
          const bodyBottom = q("[data-half='bottom'] [data-body]")[0];
          const edgeTop = q("[data-half='top'] [data-edge]")[0];
          const edgeBottom = q("[data-half='bottom'] [data-edge]")[0];
          const seams = q("[data-seam]");
          const tagline = q("[data-tagline]")[0];
          const cta = q("[data-cta]")[0];
          const cont = q("[data-continue]")[0];
          const discover = q("[data-discover]")[0];

          // Half thickness that covers the screen from the origin (+ margin).
          const geo = { ox: 0, oy: 0, L: 0, half: 0 };
          const p = { thick: 0, open: 0 };

          const measure = () => {
            const s = section.getBoundingClientRect();
            const n = nImg.getBoundingClientRect();
            geo.ox = n.left - s.left + STROKE_CENTER.x * n.width;
            geo.oy = n.top - s.top + STROKE_CENTER.y * n.height;
            const W = s.width;
            const H = s.height;
            geo.L = Math.hypot(W, H) * 3;
            const r = (STROKE_ANGLE * Math.PI) / 180;
            const nx = -Math.sin(r);
            const ny = Math.cos(r);
            geo.half =
              Math.max(...[[0, 0], [W, 0], [0, H], [W, H]].map(([x, y]) => Math.abs((x - geo.ox) * nx + (y - geo.oy) * ny))) + 24;

            // Axis: zero-height line centred on the stroke centre, at the stroke angle.
            // Position/rotation live here; the inner bar only ever scales in X.
            axis.style.width = `${geo.L}px`;
            gsap.set(axis, { x: geo.ox - geo.L / 2, y: geo.oy, rotation: STROKE_ANGLE, transformOrigin: "50% 0%" });
            gsap.set([bodyTop, bodyBottom], { height: geo.half });
            render();
          };

          // Bodies grow from the axis (scaleY), edges ride on their outer side,
          // and while opening the whole halves slide apart (translateY).
          const render = () => {
            const h = p.thick * geo.half;
            const sy = Math.max(h / geo.half, 0.00001);
            gsap.set(bodyTop, { scaleY: sy });
            gsap.set(bodyBottom, { scaleY: sy });
            gsap.set(edgeTop, { y: -h });
            gsap.set(edgeBottom, { y: h });
            const o = p.open * (geo.half + EDGE * 2);
            gsap.set(halfTop, { y: -o });
            gsap.set(halfBottom, { y: o });
          };

          gsap.set(nLayer, { autoAlpha: 1 });
          gsap.set(final, { autoAlpha: 0 });
          gsap.set(axis, { autoAlpha: 1 });
          gsap.set(bar, { autoAlpha: 0, scaleX: 0.0001, transformOrigin: "50% 0%" });
          gsap.set(seams, { autoAlpha: 0 });
          gsap.set(tagline, { yPercent: 110, autoAlpha: 1 });
          gsap.set([cta, cont], { autoAlpha: 0, y: 12 });
          measure();

          const tl = gsap.timeline({
            defaults: { ease: "none" },
            scrollTrigger: {
              trigger: section,
              start: "top top",
              end: () => `+=${window.innerHeight * (desktop ? 2.5 : 1.6)}`,
              pin: true,
              // Pre-rendered spacer: no DOM re-parenting after hydration (keeps LCP early).
              pinSpacer: spacer.current,
              scrub: 1,
              anticipatePin: 1,
              invalidateOnRefresh: true,
              onRefresh: measure,
              onUpdate: (self) =>
                setHeroState({
                  navHidden: self.progress > 0.4 && self.progress < 0.85,
                  complete: self.progress >= 0.85,
                }),
              onLeave: () => setHeroState({ past: true, complete: true, navHidden: false }),
              onEnterBack: () => setHeroState({ past: false }),
            },
          });

          tl
            // 0–35% the bar is born at the stroke centre and grows to both sides
            .to(discover, { autoAlpha: 0, y: 10, duration: 8, ease: "power2.out" }, 0)
            .set(bar, { autoAlpha: 1 }, 0.5)
            .fromTo(bar, { scaleX: 0.0001 }, { scaleX: 1, duration: 34.5, ease: "power2.inOut", immediateRender: false }, 0.5)
            // 35–65% it thickens until the screen is covered
            .fromTo(p, { thick: 0 }, { thick: 1, duration: 28, ease: "power2.inOut", onUpdate: render, immediateRender: false }, 35)
            // Covered: swap the big N for the final state (invisible under the bar)
            .set(nLayer, { autoAlpha: 0 }, 64)
            .set(final, { autoAlpha: 1 }, 64)
            .set(seams, { autoAlpha: 1 }, 64)
            // 65–85% the bar splits along its axis and the halves slide apart
            .fromTo(p, { open: 0 }, { open: 1, duration: 20, ease: "power2.inOut", onUpdate: render, immediateRender: false }, 65)
            .set(bar, { autoAlpha: 0 }, 85)
            // 85–100% closing
            .to(tagline, { yPercent: 0, duration: 6, ease: "power3.out" }, 85)
            .to(cta, { autoAlpha: 1, y: 0, duration: 6, ease: "power2.out" }, 89)
            .to(cont, { autoAlpha: 1, y: 0, duration: 5, ease: "power2.out" }, 93)
            .to({}, { duration: 2 }, 98);
        }
      );

      return () => mm.revert();
    },
    { scope: root }
  );

  return (
    <div ref={spacer}>
      <section
        ref={root}
        id="top"
        data-nav-theme="light"
        className="hero relative h-svh min-h-[560px] w-full overflow-hidden bg-off-white"
      >
        <h1 className="sr-only">{t("title")}</h1>

        {/* Final state, ready underneath from the start */}
        <div data-final className="hero-final absolute inset-0">
          <WindowLight />
          <div className="absolute inset-0 flex flex-col items-center justify-center px-6">
            <div className="w-[min(84vw,720px)] md:w-[min(60vw,720px)]">
              <BrandLogo kind="wordmark" alt="Nexora Studio" priority className="w-full" />
            </div>

            <div className="mt-10 overflow-hidden py-1 md:mt-14" aria-hidden="true">
              <p
                data-tagline
                className="hero-tagline text-center text-[11px] font-medium tracking-[0.35em] text-cinza-medio uppercase md:text-[14px]"
              >
                {t("tagline")}
              </p>
            </div>

            <div data-cta className="hero-reveal mt-9 md:mt-10">
              <WhatsAppButton variant="dark" size="sm">
                {t("cta")}
              </WhatsAppButton>
            </div>
          </div>
        </div>

        {/* The big N: same size, same transparency, until the bar covers it */}
        <div data-nlayer className="hero-n absolute inset-0 flex items-center justify-center" aria-hidden="true">
          <div data-n className="h-[min(70svh,82vw)] opacity-[0.12]">
            <BrandLogo kind="n" alt="" priority sizes="(min-width: 768px) 70vh, 82vw" className="h-full w-auto" />
          </div>
        </div>

        {/* Metallic bar: zero-height axis with two halves (top grows up, bottom grows down) */}
        <div data-axis aria-hidden="true" className="hero-bar absolute top-0 left-0 h-0">
        <div data-bar className="absolute inset-x-0 top-0 h-0 will-change-transform">
          <div data-half="top" className="absolute inset-x-0 bottom-0 will-change-transform">
            <div data-body className="hero-bar-body hero-bar-body--top absolute inset-x-0 bottom-0 origin-bottom will-change-transform" />
            <div data-seam className="hero-bar-edge absolute inset-x-0 bottom-0" style={{ height: EDGE / 2 }} />
            <div data-edge className="hero-bar-edge absolute inset-x-0 bottom-0 will-change-transform" style={{ height: EDGE }} />
          </div>
          <div data-half="bottom" className="absolute inset-x-0 top-0 will-change-transform">
            <div data-body className="hero-bar-body hero-bar-body--bottom absolute inset-x-0 top-0 origin-top will-change-transform" />
            <div data-seam className="hero-bar-edge absolute inset-x-0 top-0" style={{ height: EDGE / 2 }} />
            <div data-edge className="hero-bar-edge absolute inset-x-0 top-0 will-change-transform" style={{ height: EDGE }} />
          </div>
        </div>
        </div>

        {/* Bottom indicators */}
        <div
          data-discover
          className="hero-discover absolute inset-x-0 bottom-8 flex flex-col items-center gap-4 text-cinza-medio"
          aria-hidden="true"
        >
          <span className="text-[10px] font-medium tracking-[0.4em] uppercase">{t("discover")}</span>
          <span className="scroll-line block h-10 w-px bg-current" />
        </div>
        <div
          data-continue
          className="hero-reveal absolute inset-x-0 bottom-8 flex flex-col items-center gap-3 text-cinza-medio"
          aria-hidden="true"
        >
          <span className="text-[10px] font-medium tracking-[0.4em] uppercase">{t("continue")}</span>
          <span className="scroll-line block h-8 w-px bg-current" />
        </div>
      </section>
    </div>
  );
}
