import { useTranslations } from "next-intl";
import { SectionDecor } from "@/components/brand/SectionDecor";

const ITEMS = ["credibility", "google", "always", "independence"] as const;

export function WhyWebsite() {
  const t = useTranslations("why");

  return (
    <section
      id="por-que"
      data-nav-theme="light"
      aria-labelledby="why-title"
      className="relative overflow-hidden bg-off-white px-5 py-28 md:px-10 md:py-40"
    >
      <SectionDecor index={3} watermark="right" />
      <div className="relative z-10 mx-auto max-w-[1320px]">
        <div className="grid gap-10 md:grid-cols-12">
          <div className="md:col-span-5">
            <p data-reveal className="eyebrow text-cinza-escuro">
              {t("eyebrow")}
            </p>
          </div>
          <h2
            id="why-title"
            data-reveal
            className="text-[34px] leading-[1.08] font-medium tracking-[-0.03em] text-balance md:col-span-7 md:text-[56px]"
          >
            {t("title")}
          </h2>
        </div>

        <ol className="mt-20 grid border-t border-cinza-claro md:mt-28 md:grid-cols-2">
          {ITEMS.map((key, i) => (
            <li
              key={key}
              data-reveal
              className={`flex gap-6 border-b border-cinza-claro py-10 md:gap-10 md:py-14 ${
                i % 2 === 0 ? "md:border-r md:pr-12" : "md:pl-12"
              }`}
            >
              <span
                aria-hidden="true"
                className="w-14 shrink-0 text-[40px] leading-none font-extralight tracking-[-0.04em] text-cinza-medio tabular-nums md:w-20 md:text-[56px]"
              >
                {String(i + 1).padStart(2, "0")}
              </span>
              <div className="pt-1">
                <h3 className="text-[20px] font-semibold tracking-[-0.015em] md:text-[22px]">
                  {t(`items.${key}.title`)}
                </h3>
                <p className="mt-3 max-w-[38ch] text-[15px] leading-relaxed text-cinza-escuro md:text-base">
                  {t(`items.${key}.text`)}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
