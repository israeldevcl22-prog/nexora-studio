import { useLocale, useTranslations } from "next-intl";
import { BrandLogo } from "@/components/brand/BrandLogo";
import { LocaleSwitcher } from "@/components/ui/LocaleSwitcher";
import { WhatsAppIcon } from "@/components/ui/icons";
import { site } from "@/lib/site";
import { whatsappLink } from "@/lib/whatsapp";

export function Footer() {
  const t = useTranslations("footer");
  const locale = useLocale();

  const link =
    "inline-flex items-center gap-2.5 rounded-sm text-cinza-claro transition-colors duration-300 hover:text-off-white focus-visible:outline-1 focus-visible:outline-offset-4 focus-visible:outline-off-white";

  return (
    <footer id="rodape" data-nav-theme="dark" className="bg-preto px-5 pt-20 pb-10 text-off-white md:px-10 md:pt-28">
      <div className="mx-auto max-w-[1320px]">
        <div className="flex flex-col gap-14 md:flex-row md:items-end md:justify-between">
          <BrandLogo kind="horizontal" tone="light" sizes="280px" className="h-12 w-auto md:h-14" />
          <p className="text-[11px] font-medium tracking-[0.35em] text-cinza-medio uppercase">
            {t("tagline")}
          </p>
        </div>

        <div className="mt-16 flex flex-col gap-10 border-t border-cinza-escuro pt-10 md:flex-row md:items-center md:justify-between">
          <ul aria-label={t("contact")} className="flex flex-col gap-4 text-[15px] sm:flex-row sm:gap-10">
            <li>
              <a href={whatsappLink(locale)} target="_blank" rel="noopener noreferrer" className={link}>
                <WhatsAppIcon className="size-[18px]" />
                {t("whatsapp")}
              </a>
            </li>
            <li>
              <a href={`mailto:${site.email}`} className={link}>
                {site.email}
              </a>
            </li>
            {/* TODO: adicionar Instagram
            <li>
              <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer" className={link} aria-label="Instagram">
                <InstagramIcon className="size-[18px]" />
                Instagram
              </a>
            </li>
            */}
          </ul>
          <LocaleSwitcher tone="light" />
        </div>

        <p className="mt-14 text-[12px] text-cinza-medio">{t("rights")}</p>
      </div>
    </footer>
  );
}
